class Payment:
    id = int;