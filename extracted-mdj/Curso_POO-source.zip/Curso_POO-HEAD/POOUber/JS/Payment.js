function Payment() {
    this.id;
}