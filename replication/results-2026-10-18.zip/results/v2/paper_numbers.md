## Corpus totals
- commits: 2606; runs: 10424
- androuter: 35 commits; touched source 16/34; changed conformance 5/34
- angular-fullstack-pro-starter: 14 commits; touched source 7/13; changed conformance 0/13
- artvance: 25 commits; touched source 5/24; changed conformance 4/24
- astrominer: 94 commits; touched source 84/93; changed conformance 73/93
- bankthread: 7 commits; touched source 5/6; changed conformance 4/6
- banquale: 34 commits; touched source 12/33; changed conformance 6/33
- board-game: 11 commits; touched source 6/10; changed conformance 1/10
- codearteng-diagnostics: 12 commits; touched source 7/11; changed conformance 4/11
- codingame-puzzles-stats-library: 150 commits; touched source 57/149; changed conformance 31/149
- commandandcontrolsystem-lds: 13 commits; touched source 12/12; changed conformance 0/12
- cookpot: 57 commits; touched source 47/56; changed conformance 17/56
- covid-vaccination-system: 12 commits; touched source 4/11; changed conformance 0/11
- discordbotrpg: 104 commits; touched source 62/103; changed conformance 12/103
- django-business-logic: 27 commits; touched source 7/26; changed conformance 1/26
- fire-app-builder: 18 commits; touched source 17/17; changed conformance 4/17
- forma-tech: 10 commits; touched source 6/9; changed conformance 5/9
- formula1-fisica: 37 commits; touched source 7/36; changed conformance 3/36
- galaxy-data-mines: 19 commits; touched source 9/18; changed conformance 2/18
- gamespark: 13 commits; touched source 1/12; changed conformance 0/12
- gdxiris: 24 commits; touched source 12/23; changed conformance 4/23
- genetic-algorithm: 56 commits; touched source 53/55; changed conformance 26/55
- gestvae: 150 commits; touched source 74/149; changed conformance 51/149
- hotelaurademallorca: 150 commits; touched source 149/149; changed conformance 7/149
- hydgl: 72 commits; touched source 71/71; changed conformance 3/71
- ing-sw-2019-mauri-murriero-ostrovan: 114 commits; touched source 59/113; changed conformance 37/113
- is1-project-audio-streaming-system: 9 commits; touched source 8/8; changed conformance 0/8
- library-web-api: 22 commits; touched source 5/21; changed conformance 0/21
- meeting-room-display: 16 commits; touched source 6/15; changed conformance 1/15
- minesweeper: 98 commits; touched source 97/97; changed conformance 15/97
- model-wolf-sheep: 16 commits; touched source 6/15; changed conformance 1/15
- mschartextension: 30 commits; touched source 19/29; changed conformance 12/29
- open-market: 58 commits; touched source 57/57; changed conformance 15/57
- openpose-unity-plugin: 16 commits; touched source 11/15; changed conformance 3/15
- pbl03-dut-dk88: 36 commits; touched source 10/35; changed conformance 7/35
- poker-bot-deep-rl: 81 commits; touched source 80/80; changed conformance 13/80
- preprocessinglayer-nordjyske: 60 commits; touched source 58/59; changed conformance 4/59
- prism-php: 67 commits; touched source 66/66; changed conformance 8/66
- projet-cy-books: 48 commits; touched source 24/47; changed conformance 7/47
- projet-hotel: 18 commits; touched source 13/17; changed conformance 8/17
- rdf4node: 150 commits; touched source 149/149; changed conformance 19/149
- scs-simulation-of-insulin-pump: 26 commits; touched source 25/25; changed conformance 0/25
- sistema-bancario: 25 commits; touched source 8/24; changed conformance 0/24
- soulland: 93 commits; touched source 53/92; changed conformance 31/92
- spring6plus: 38 commits; touched source 9/37; changed conformance 3/37
- tankman: 37 commits; touched source 29/36; changed conformance 8/36
- translator: 12 commits; touched source 3/11; changed conformance 2/11
- usms-web: 27 commits; touched source 6/26; changed conformance 2/26
- vars-annotation: 150 commits; touched source 148/149; changed conformance 31/149
- vectorx: 61 commits; touched source 30/60; changed conformance 11/60
- virtualq-final-version: 4 commits; touched source 3/3; changed conformance 1/3
- vscode-nativescript-extend: 126 commits; touched source 34/125; changed conformance 5/125
- xtask: 24 commits; touched source 23/23; changed conformance 7/23
- pooled: 514/2554 commits changed conformance (20.1%, CI 18.6%–21.7%); 1769/2554 touched source; changed among touching: 514/1769

## Gate table (pooled)
| Gate | Runs | Re-analysed | Skip rate [95% CI] | Recall [95% CI] (n) | Specificity [95% CI] (n) | Stale runs | Counterfactual tokens | Saved vs always |
|---|---|---|---|---|---|---|---|---|
| always | 2606 | 2606 | 0.0% [0.0%–0.0%] | 100.0% [99.0%–100.0%] (514) | 0.0% [0.0%–0.0%] (2040) | 0 (0.0%) | 266,884,290 | — |
| content | 2606 | 1399 | 46.0% [44.0%–48.0%] | 100.0% [99.0%–100.0%] (514) | 59.0% [57.0%–61.0%] (2040) | 0 (0.0%) | 45,800,517 | 83.0% |
| structural | 2606 | 1049 | 60.0% [58.0%–62.0%] | 100.0% [99.0%–100.0%] (514) | 76.0% [74.0%–78.0%] (2040) | 0 (0.0%) | 21,418,687 | 92.0% |
| isomorphism | 2606 | 872 | 67.0% [65.0%–68.0%] | 93.0% [90.0%–95.0%] (514) | 83.0% [82.0%–85.0%] (2040) | 117 (4.0%) | 20,108,416 | 92.0% |
- recovery always: {"misses_tracked": 0, "resolved_count": 0, "censored_count": 0, "median_commits": null, "censored_beyond": null, "max_resolved": null}
- recovery content: {"misses_tracked": 0, "resolved_count": 0, "censored_count": 0, "median_commits": null, "censored_beyond": null, "max_resolved": null}
- recovery structural: {"misses_tracked": 0, "resolved_count": 0, "censored_count": 0, "median_commits": null, "censored_beyond": null, "max_resolved": null}
- recovery isomorphism: {"misses_tracked": 32, "resolved_count": 29, "censored_count": 3, "median_commits": 2.0, "censored_beyond": null, "max_resolved": 9}

- recommended: {'gate': 'structural', 'skip_rate': 0.6, 'missed': 0, 'tokens_saved': 0, 'safe': True, 'reason': '`structural` is the most economical gate that missed nothing: it skipped 60.0% of runs and saved 0 tokens.'}
- comparison: {"paired_observations": 2606, "left_only": 177, "right_only": 0, "discordant": 177, "agreed": 2429, "p_value": 1.044048714879764e-53, "usable": true, "reason": "", "left": "structural", "right": "isomorphism", "p_text": "below 0.001", "reading": "On the 2606 commits both gates saw, they disagreed 177 times: `structural` re-analysed and `isomorphism` skipped on 177, the reverse on 0. That split is too lopsided to be chance (McNemar's exact test, p below 0.001), so the difference between these two gates is real rather than an accident of which commits happened to be in the corpus."}

## Per-project, per-gate
| Project | Gate | Commits | Skip rate | Re-analysed | Stale runs | Counterfactual tokens |
|---|---|---|---|---|---|---|
| androuter | always | 35 | 0.0% | 35 | 0 | 986,956 |
| androuter | content | 35 | 51.4% | 17 | 0 | 208,120 (78.9% saved) |
| androuter | structural | 35 | 54.3% | 16 | 0 | 182,991 (81.5% saved) |
| androuter | isomorphism | 35 | 57.1% | 15 | 0 | 177,914 (82.0% saved) |
| angular-fullstack-pro-starter | always | 14 | 0.0% | 14 | 0 | 366,805 |
| angular-fullstack-pro-starter | content | 14 | 78.6% | 3 | 0 | 29,777 (91.9% saved) |
| angular-fullstack-pro-starter | structural | 14 | 78.6% | 3 | 0 | 29,777 (91.9% saved) |
| angular-fullstack-pro-starter | isomorphism | 14 | 92.9% | 1 | 0 | 24,030 (93.4% saved) |
| artvance | always | 25 | 0.0% | 25 | 0 | 237,697 |
| artvance | content | 25 | 76.0% | 6 | 0 | 40,873 (82.8% saved) |
| artvance | structural | 25 | 80.0% | 5 | 0 | 31,495 (86.7% saved) |
| artvance | isomorphism | 25 | 84.0% | 4 | 6 | 27,139 (88.6% saved) |
| astrominer | always | 94 | 0.0% | 94 | 0 | 11,077,328 |
| astrominer | content | 94 | 9.6% | 85 | 0 | 1,726,887 (84.4% saved) |
| astrominer | structural | 94 | 12.8% | 82 | 0 | 1,379,903 (87.5% saved) |
| astrominer | isomorphism | 94 | 13.8% | 81 | 0 | 1,376,705 (87.6% saved) |
| bankthread | always | 7 | 0.0% | 7 | 0 | 41,237 |
| bankthread | content | 7 | 14.3% | 6 | 0 | 26,008 (36.9% saved) |
| bankthread | structural | 7 | 28.6% | 5 | 0 | 20,518 (50.2% saved) |
| bankthread | isomorphism | 7 | 28.6% | 5 | 0 | 20,518 (50.2% saved) |
| banquale | always | 34 | 0.0% | 34 | 0 | 909,900 |
| banquale | content | 34 | 64.7% | 12 | 0 | 184,857 (79.7% saved) |
| banquale | structural | 34 | 73.5% | 9 | 0 | 108,415 (88.1% saved) |
| banquale | isomorphism | 34 | 76.5% | 8 | 0 | 101,515 (88.8% saved) |
| board-game | always | 11 | 0.0% | 11 | 0 | 303,648 |
| board-game | content | 11 | 45.5% | 6 | 0 | 87,303 (71.2% saved) |
| board-game | structural | 11 | 54.5% | 5 | 0 | 61,845 (79.6% saved) |
| board-game | isomorphism | 11 | 72.7% | 3 | 0 | 47,129 (84.5% saved) |
| codearteng-diagnostics | always | 12 | 0.0% | 12 | 0 | 190,787 |
| codearteng-diagnostics | content | 12 | 41.7% | 7 | 0 | 64,734 (66.1% saved) |
| codearteng-diagnostics | structural | 12 | 41.7% | 7 | 0 | 64,734 (66.1% saved) |
| codearteng-diagnostics | isomorphism | 12 | 50.0% | 6 | 0 | 58,856 (69.2% saved) |
| codingame-puzzles-stats-library | always | 150 | 0.0% | 150 | 0 | 1,897,941 |
| codingame-puzzles-stats-library | content | 150 | 61.3% | 58 | 0 | 301,779 (84.1% saved) |
| codingame-puzzles-stats-library | structural | 150 | 66.0% | 51 | 0 | 228,505 (88.0% saved) |
| codingame-puzzles-stats-library | isomorphism | 150 | 78.0% | 33 | 13 | 146,906 (92.3% saved) |
| commandandcontrolsystem-lds | always | 13 | 0.0% | 13 | 0 | 1,095,117 |
| commandandcontrolsystem-lds | content | 13 | 53.8% | 6 | 0 | 186,855 (82.9% saved) |
| commandandcontrolsystem-lds | structural | 13 | 61.5% | 5 | 0 | 112,776 (89.7% saved) |
| commandandcontrolsystem-lds | isomorphism | 13 | 61.5% | 5 | 0 | 112,776 (89.7% saved) |
| cookpot | always | 57 | 0.0% | 57 | 0 | 622,951 |
| cookpot | content | 57 | 15.8% | 48 | 0 | 283,749 (54.5% saved) |
| cookpot | structural | 57 | 24.6% | 43 | 0 | 237,647 (61.9% saved) |
| cookpot | isomorphism | 57 | 35.1% | 37 | 1 | 207,703 (66.7% saved) |
| covid-vaccination-system | always | 12 | 0.0% | 12 | 0 | 256,459 |
| covid-vaccination-system | content | 12 | 66.7% | 4 | 0 | 73,639 (71.3% saved) |
| covid-vaccination-system | structural | 12 | 83.3% | 2 | 0 | 32,905 (87.2% saved) |
| covid-vaccination-system | isomorphism | 12 | 83.3% | 2 | 0 | 32,905 (87.2% saved) |
| discordbotrpg | always | 104 | 0.0% | 104 | 0 | 18,838,912 |
| discordbotrpg | content | 104 | 39.4% | 63 | 0 | 6,747,687 (64.2% saved) |
| discordbotrpg | structural | 104 | 67.3% | 34 | 0 | 1,311,608 (93.0% saved) |
| discordbotrpg | isomorphism | 104 | 67.3% | 34 | 0 | 1,311,608 (93.0% saved) |
| django-business-logic | always | 27 | 0.0% | 27 | 0 | 3,190,742 |
| django-business-logic | content | 27 | 70.4% | 8 | 0 | 822,572 (74.2% saved) |
| django-business-logic | structural | 27 | 92.6% | 2 | 0 | 145,016 (95.5% saved) |
| django-business-logic | isomorphism | 27 | 92.6% | 2 | 0 | 145,016 (95.5% saved) |
| fire-app-builder | always | 18 | 0.0% | 18 | 0 | 14,301,223 |
| fire-app-builder | content | 18 | 61.1% | 7 | 0 | 2,793,891 (80.5% saved) |
| fire-app-builder | structural | 18 | 61.1% | 7 | 0 | 2,793,891 (80.5% saved) |
| fire-app-builder | isomorphism | 18 | 61.1% | 7 | 0 | 2,793,891 (80.5% saved) |
| forma-tech | always | 10 | 0.0% | 10 | 0 | 214,860 |
| forma-tech | content | 10 | 30.0% | 7 | 0 | 59,283 (72.4% saved) |
| forma-tech | structural | 10 | 30.0% | 7 | 0 | 59,283 (72.4% saved) |
| forma-tech | isomorphism | 10 | 30.0% | 7 | 0 | 59,283 (72.4% saved) |
| formula1-fisica | always | 37 | 0.0% | 37 | 0 | 256,647 |
| formula1-fisica | content | 37 | 78.4% | 8 | 0 | 38,548 (85.0% saved) |
| formula1-fisica | structural | 37 | 81.1% | 7 | 0 | 33,259 (87.0% saved) |
| formula1-fisica | isomorphism | 37 | 83.8% | 6 | 0 | 29,647 (88.4% saved) |
| galaxy-data-mines | always | 19 | 0.0% | 19 | 0 | 363,320 |
| galaxy-data-mines | content | 19 | 57.9% | 8 | 0 | 90,924 (75.0% saved) |
| galaxy-data-mines | structural | 19 | 63.2% | 7 | 0 | 72,267 (80.1% saved) |
| galaxy-data-mines | isomorphism | 19 | 89.5% | 2 | 4 | 27,784 (92.4% saved) |
| gamespark | always | 13 | 0.0% | 13 | 0 | 719,066 |
| gamespark | content | 13 | 84.6% | 2 | 0 | 67,594 (90.6% saved) |
| gamespark | structural | 13 | 84.6% | 2 | 0 | 67,594 (90.6% saved) |
| gamespark | isomorphism | 13 | 84.6% | 2 | 0 | 67,594 (90.6% saved) |
| gdxiris | always | 24 | 0.0% | 24 | 0 | 172,794 |
| gdxiris | content | 24 | 45.8% | 13 | 0 | 53,052 (69.3% saved) |
| gdxiris | structural | 24 | 54.2% | 11 | 0 | 37,829 (78.1% saved) |
| gdxiris | isomorphism | 24 | 62.5% | 9 | 0 | 33,268 (80.7% saved) |
| genetic-algorithm | always | 56 | 0.0% | 56 | 0 | 2,495,346 |
| genetic-algorithm | content | 56 | 5.4% | 53 | 0 | 1,253,959 (49.7% saved) |
| genetic-algorithm | structural | 56 | 23.2% | 43 | 0 | 835,172 (66.5% saved) |
| genetic-algorithm | isomorphism | 56 | 42.9% | 32 | 4 | 648,771 (74.0% saved) |
| gestvae | always | 150 | 0.0% | 150 | 0 | 5,010,201 |
| gestvae | content | 150 | 51.3% | 73 | 0 | 816,333 (83.7% saved) |
| gestvae | structural | 150 | 59.3% | 61 | 0 | 441,241 (91.2% saved) |
| gestvae | isomorphism | 150 | 64.0% | 54 | 10 | 395,483 (92.1% saved) |
| hotelaurademallorca | always | 150 | 0.0% | 150 | 0 | 7,732,348 |
| hotelaurademallorca | content | 150 | 40.7% | 89 | 0 | 2,612,977 (66.2% saved) |
| hotelaurademallorca | structural | 150 | 74.0% | 39 | 0 | 282,688 (96.3% saved) |
| hotelaurademallorca | isomorphism | 150 | 82.7% | 26 | 8 | 216,914 (97.2% saved) |
| hydgl | always | 72 | 0.0% | 72 | 0 | 5,108,611 |
| hydgl | content | 72 | 63.9% | 26 | 0 | 1,037,377 (79.7% saved) |
| hydgl | structural | 72 | 81.9% | 13 | 0 | 253,721 (95.0% saved) |
| hydgl | isomorphism | 72 | 81.9% | 13 | 0 | 253,721 (95.0% saved) |
| ing-sw-2019-mauri-murriero-ostrovan | always | 114 | 0.0% | 114 | 0 | 4,118,023 |
| ing-sw-2019-mauri-murriero-ostrovan | content | 114 | 47.4% | 60 | 0 | 906,761 (78.0% saved) |
| ing-sw-2019-mauri-murriero-ostrovan | structural | 114 | 50.0% | 57 | 0 | 792,365 (80.8% saved) |
| ing-sw-2019-mauri-murriero-ostrovan | isomorphism | 114 | 58.8% | 47 | 0 | 696,712 (83.1% saved) |
| is1-project-audio-streaming-system | always | 9 | 0.0% | 9 | 0 | 1,197,788 |
| is1-project-audio-streaming-system | content | 9 | 88.9% | 1 | 0 | 125,372 (89.5% saved) |
| is1-project-audio-streaming-system | structural | 9 | 88.9% | 1 | 0 | 125,372 (89.5% saved) |
| is1-project-audio-streaming-system | isomorphism | 9 | 88.9% | 1 | 0 | 125,372 (89.5% saved) |
| library-web-api | always | 22 | 0.0% | 22 | 0 | 469,608 |
| library-web-api | content | 22 | 86.4% | 3 | 0 | 60,875 (87.0% saved) |
| library-web-api | structural | 22 | 95.5% | 1 | 0 | 20,290 (95.7% saved) |
| library-web-api | isomorphism | 22 | 95.5% | 1 | 0 | 20,290 (95.7% saved) |
| meeting-room-display | always | 16 | 0.0% | 16 | 0 | 871,193 |
| meeting-room-display | content | 16 | 56.2% | 7 | 0 | 221,869 (74.5% saved) |
| meeting-room-display | structural | 16 | 75.0% | 4 | 0 | 72,857 (91.6% saved) |
| meeting-room-display | isomorphism | 16 | 81.2% | 3 | 0 | 63,560 (92.7% saved) |
| minesweeper | always | 98 | 0.0% | 98 | 0 | 2,267,650 |
| minesweeper | content | 98 | 32.7% | 66 | 0 | 634,414 (72.0% saved) |
| minesweeper | structural | 98 | 58.2% | 41 | 0 | 161,185 (92.9% saved) |
| minesweeper | isomorphism | 98 | 66.3% | 33 | 0 | 136,918 (94.0% saved) |
| model-wolf-sheep | always | 16 | 0.0% | 16 | 0 | 79,730 |
| model-wolf-sheep | content | 16 | 56.2% | 7 | 0 | 30,150 (62.2% saved) |
| model-wolf-sheep | structural | 16 | 81.2% | 3 | 0 | 11,412 (85.7% saved) |
| model-wolf-sheep | isomorphism | 16 | 81.2% | 3 | 0 | 11,412 (85.7% saved) |
| mschartextension | always | 30 | 0.0% | 30 | 0 | 1,023,363 |
| mschartextension | content | 30 | 33.3% | 20 | 0 | 415,938 (59.4% saved) |
| mschartextension | structural | 30 | 40.0% | 18 | 0 | 340,925 (66.7% saved) |
| mschartextension | isomorphism | 30 | 50.0% | 15 | 3 | 296,724 (71.0% saved) |
| open-market | always | 58 | 0.0% | 58 | 0 | 8,869,919 |
| open-market | content | 58 | 17.2% | 48 | 0 | 1,679,247 (81.1% saved) |
| open-market | structural | 58 | 19.0% | 47 | 0 | 1,509,747 (83.0% saved) |
| open-market | isomorphism | 58 | 19.0% | 47 | 0 | 1,509,747 (83.0% saved) |
| openpose-unity-plugin | always | 16 | 0.0% | 16 | 0 | 326,767 |
| openpose-unity-plugin | content | 16 | 50.0% | 8 | 0 | 112,493 (65.6% saved) |
| openpose-unity-plugin | structural | 16 | 68.8% | 5 | 0 | 57,125 (82.5% saved) |
| openpose-unity-plugin | isomorphism | 16 | 75.0% | 4 | 0 | 47,247 (85.5% saved) |
| pbl03-dut-dk88 | always | 36 | 0.0% | 36 | 0 | 470,619 |
| pbl03-dut-dk88 | content | 36 | 69.4% | 11 | 0 | 110,329 (76.6% saved) |
| pbl03-dut-dk88 | structural | 36 | 69.4% | 11 | 0 | 110,329 (76.6% saved) |
| pbl03-dut-dk88 | isomorphism | 36 | 69.4% | 11 | 0 | 110,329 (76.6% saved) |
| poker-bot-deep-rl | always | 81 | 0.0% | 81 | 0 | 10,128,781 |
| poker-bot-deep-rl | content | 81 | 33.3% | 54 | 0 | 1,672,954 (83.5% saved) |
| poker-bot-deep-rl | structural | 81 | 40.7% | 48 | 0 | 1,160,940 (88.5% saved) |
| poker-bot-deep-rl | isomorphism | 81 | 40.7% | 48 | 0 | 1,160,940 (88.5% saved) |
| preprocessinglayer-nordjyske | always | 60 | 0.0% | 60 | 0 | 4,434,866 |
| preprocessinglayer-nordjyske | content | 60 | 70.0% | 18 | 0 | 599,351 (86.5% saved) |
| preprocessinglayer-nordjyske | structural | 60 | 80.0% | 12 | 0 | 187,781 (95.8% saved) |
| preprocessinglayer-nordjyske | isomorphism | 60 | 91.7% | 5 | 13 | 132,860 (97.0% saved) |
| prism-php | always | 67 | 0.0% | 67 | 0 | 1,692,954 |
| prism-php | content | 67 | 32.8% | 45 | 0 | 639,676 (62.2% saved) |
| prism-php | structural | 67 | 65.7% | 23 | 0 | 130,444 (92.3% saved) |
| prism-php | isomorphism | 67 | 89.6% | 7 | 23 | 53,336 (96.8% saved) |
| projet-cy-books | always | 48 | 0.0% | 48 | 0 | 5,454,620 |
| projet-cy-books | content | 48 | 47.9% | 25 | 0 | 1,355,079 (75.2% saved) |
| projet-cy-books | structural | 48 | 62.5% | 18 | 0 | 611,206 (88.8% saved) |
| projet-cy-books | isomorphism | 48 | 62.5% | 18 | 0 | 611,206 (88.8% saved) |
| projet-hotel | always | 18 | 0.0% | 18 | 0 | 390,377 |
| projet-hotel | content | 18 | 33.3% | 12 | 0 | 135,855 (65.2% saved) |
| projet-hotel | structural | 18 | 38.9% | 11 | 0 | 116,480 (70.2% saved) |
| projet-hotel | isomorphism | 18 | 55.6% | 8 | 3 | 98,282 (74.8% saved) |
| rdf4node | always | 150 | 0.0% | 150 | 0 | 8,854,633 |
| rdf4node | content | 150 | 9.3% | 136 | 0 | 3,786,882 (57.2% saved) |
| rdf4node | structural | 150 | 46.0% | 81 | 0 | 742,038 (91.6% saved) |
| rdf4node | isomorphism | 150 | 70.7% | 44 | 13 | 438,954 (95.0% saved) |
| scs-simulation-of-insulin-pump | always | 26 | 0.0% | 26 | 0 | 8,039,086 |
| scs-simulation-of-insulin-pump | content | 26 | 88.5% | 3 | 0 | 607,810 (92.4% saved) |
| scs-simulation-of-insulin-pump | structural | 26 | 92.3% | 2 | 0 | 308,006 (96.2% saved) |
| scs-simulation-of-insulin-pump | isomorphism | 26 | 92.3% | 2 | 0 | 308,006 (96.2% saved) |
| sistema-bancario | always | 25 | 0.0% | 25 | 0 | 212,325 |
| sistema-bancario | content | 25 | 64.0% | 9 | 0 | 57,085 (73.1% saved) |
| sistema-bancario | structural | 25 | 88.0% | 3 | 0 | 13,551 (93.6% saved) |
| sistema-bancario | isomorphism | 25 | 96.0% | 1 | 0 | 7,167 (96.6% saved) |
| soulland | always | 93 | 0.0% | 93 | 0 | 1,770,801 |
| soulland | content | 93 | 41.9% | 54 | 0 | 434,620 (75.5% saved) |
| soulland | structural | 93 | 55.9% | 41 | 0 | 221,839 (87.5% saved) |
| soulland | isomorphism | 93 | 58.1% | 39 | 1 | 215,413 (87.8% saved) |
| spring6plus | always | 38 | 0.0% | 38 | 0 | 3,273,678 |
| spring6plus | content | 38 | 73.7% | 10 | 0 | 288,249 (91.2% saved) |
| spring6plus | structural | 38 | 76.3% | 9 | 0 | 208,667 (93.6% saved) |
| spring6plus | isomorphism | 38 | 78.9% | 8 | 0 | 164,163 (95.0% saved) |
| tankman | always | 37 | 0.0% | 37 | 0 | 910,506 |
| tankman | content | 37 | 18.9% | 30 | 0 | 537,906 (40.9% saved) |
| tankman | structural | 37 | 54.1% | 17 | 0 | 243,587 (73.2% saved) |
| tankman | isomorphism | 37 | 70.3% | 11 | 9 | 180,977 (80.1% saved) |
| translator | always | 12 | 0.0% | 12 | 0 | 195,060 |
| translator | content | 12 | 66.7% | 4 | 0 | 36,211 (81.4% saved) |
| translator | structural | 12 | 66.7% | 4 | 0 | 36,211 (81.4% saved) |
| translator | isomorphism | 12 | 83.3% | 2 | 6 | 23,743 (87.8% saved) |
| usms-web | always | 27 | 0.0% | 27 | 0 | 280,768 |
| usms-web | content | 27 | 74.1% | 7 | 0 | 38,955 (86.1% saved) |
| usms-web | structural | 27 | 81.5% | 5 | 0 | 20,343 (92.8% saved) |
| usms-web | isomorphism | 27 | 81.5% | 5 | 0 | 20,343 (92.8% saved) |
| vars-annotation | always | 150 | 0.0% | 150 | 0 | 115,294,105 |
| vars-annotation | content | 150 | 47.3% | 79 | 0 | 10,069,451 (91.3% saved) |
| vars-annotation | structural | 150 | 52.0% | 72 | 0 | 4,405,014 (96.2% saved) |
| vars-annotation | isomorphism | 150 | 52.0% | 72 | 0 | 4,405,014 (96.2% saved) |
| vectorx | always | 61 | 0.0% | 61 | 0 | 3,150,465 |
| vectorx | content | 61 | 59.0% | 25 | 0 | 279,204 (91.1% saved) |
| vectorx | structural | 61 | 60.7% | 24 | 0 | 231,451 (92.7% saved) |
| vectorx | isomorphism | 61 | 62.3% | 23 | 0 | 227,144 (92.8% saved) |
| virtualq-final-version | always | 4 | 0.0% | 4 | 0 | 433,941 |
| virtualq-final-version | content | 4 | 50.0% | 2 | 0 | 135,549 (68.8% saved) |
| virtualq-final-version | structural | 4 | 50.0% | 2 | 0 | 135,549 (68.8% saved) |
| virtualq-final-version | isomorphism | 4 | 50.0% | 2 | 0 | 135,549 (68.8% saved) |
| vscode-nativescript-extend | always | 126 | 0.0% | 126 | 0 | 2,704,287 |
| vscode-nativescript-extend | content | 126 | 77.8% | 28 | 0 | 390,009 (85.6% saved) |
| vscode-nativescript-extend | structural | 126 | 89.7% | 13 | 0 | 94,994 (96.5% saved) |
| vscode-nativescript-extend | isomorphism | 126 | 93.7% | 8 | 0 | 66,033 (97.6% saved) |
| xtask | always | 24 | 0.0% | 24 | 0 | 3,577,481 |
| xtask | content | 24 | 50.0% | 12 | 0 | 829,445 (76.8% saved) |
| xtask | structural | 24 | 58.3% | 10 | 0 | 523,899 (85.4% saved) |
| xtask | isomorphism | 24 | 58.3% | 10 | 0 | 523,899 (85.4% saved) |

## Drift
- {"project": "androuter", "commits": 35, "divergences_start": 45, "divergences_end": 46, "absences_start": 15, "absences_end": 15, "net_divergence": 1, "net_absence": 0, "drift_per_commit": 0.03, "drift_per_touching_commit": 0.06, "eroding_commits": 3, "repairing_commits": 2, "conformance_changing_commits": 5, "source_touching_commits": 16, "similarity_start": 25.0, "similarity_end": 25.0, "similarity_min": 25.0, "direction": "divergence-led"}
- {"project": "angular-fullstack-pro-starter", "commits": 14, "divergences_start": 31, "divergences_end": 31, "absences_start": 27, "absences_end": 27, "net_divergence": 0, "net_absence": 0, "drift_per_commit": 0, "drift_per_touching_commit": 0, "eroding_commits": 0, "repairing_commits": 0, "conformance_changing_commits": 0, "source_touching_commits": 7, "similarity_start": 24.0, "similarity_end": 24.0, "similarity_min": 24.0, "direction": "stable"}
- {"project": "artvance", "commits": 25, "divergences_start": 25, "divergences_end": 33, "absences_start": 70, "absences_end": 75, "net_divergence": 8, "net_absence": 5, "drift_per_commit": 0.54, "drift_per_touching_commit": 2.6, "eroding_commits": 4, "repairing_commits": 0, "conformance_changing_commits": 4, "source_touching_commits": 5, "similarity_start": 15.0, "similarity_end": 15.15, "similarity_min": 15.0, "direction": "divergence-led"}
- {"project": "astrominer", "commits": 94, "divergences_start": 44, "divergences_end": 521, "absences_start": 25, "absences_end": 35, "net_divergence": 477, "net_absence": 10, "drift_per_commit": 5.24, "drift_per_touching_commit": 5.8, "eroding_commits": 65, "repairing_commits": 7, "conformance_changing_commits": 73, "source_touching_commits": 84, "similarity_start": 42.86, "similarity_end": 15.15, "similarity_min": 12.12, "direction": "divergence-led"}
- {"project": "bankthread", "commits": 7, "divergences_start": 29, "divergences_end": 38, "absences_start": 10, "absences_end": 10, "net_divergence": 9, "net_absence": 0, "drift_per_commit": 1.5, "drift_per_touching_commit": 1.8, "eroding_commits": 2, "repairing_commits": 2, "conformance_changing_commits": 4, "source_touching_commits": 5, "similarity_start": 57.14, "similarity_end": 57.14, "similarity_min": 57.14, "direction": "divergence-led"}
- {"project": "banquale", "commits": 34, "divergences_start": 51, "divergences_end": 58, "absences_start": 18, "absences_end": 18, "net_divergence": 7, "net_absence": 0, "drift_per_commit": 0.21, "drift_per_touching_commit": 0.58, "eroding_commits": 4, "repairing_commits": 2, "conformance_changing_commits": 6, "source_touching_commits": 12, "similarity_start": 77.94, "similarity_end": 79.17, "similarity_min": 77.94, "direction": "divergence-led"}
- {"project": "board-game", "commits": 11, "divergences_start": 53, "divergences_end": 52, "absences_start": 36, "absences_end": 36, "net_divergence": -1, "net_absence": 0, "drift_per_commit": -0.1, "drift_per_touching_commit": -0.17, "eroding_commits": 0, "repairing_commits": 1, "conformance_changing_commits": 1, "source_touching_commits": 6, "similarity_start": 82.76, "similarity_end": 82.76, "similarity_min": 82.76, "direction": "converging"}
- {"project": "codearteng-diagnostics", "commits": 12, "divergences_start": 84, "divergences_end": 95, "absences_start": 18, "absences_end": 18, "net_divergence": 11, "net_absence": 0, "drift_per_commit": 1, "drift_per_touching_commit": 1.57, "eroding_commits": 4, "repairing_commits": 0, "conformance_changing_commits": 4, "source_touching_commits": 7, "similarity_start": 71.15, "similarity_end": 71.15, "similarity_min": 71.15, "direction": "divergence-led"}
- {"project": "codingame-puzzles-stats-library", "commits": 150, "divergences_start": 17, "divergences_end": 80, "absences_start": 12, "absences_end": 15, "net_divergence": 63, "net_absence": 3, "drift_per_commit": 0.44, "drift_per_touching_commit": 1.16, "eroding_commits": 23, "repairing_commits": 3, "conformance_changing_commits": 31, "source_touching_commits": 57, "similarity_start": 83.33, "similarity_end": 75.51, "similarity_min": 51.85, "direction": "divergence-led"}
- {"project": "commandandcontrolsystem-lds", "commits": 13, "divergences_start": 146, "divergences_end": 146, "absences_start": 16, "absences_end": 16, "net_divergence": 0, "net_absence": 0, "drift_per_commit": 0, "drift_per_touching_commit": 0, "eroding_commits": 0, "repairing_commits": 0, "conformance_changing_commits": 0, "source_touching_commits": 12, "similarity_start": 65.22, "similarity_end": 65.22, "similarity_min": 65.22, "direction": "stable"}
- {"project": "cookpot", "commits": 57, "divergences_start": 9, "divergences_end": 36, "absences_start": 25, "absences_end": 39, "net_divergence": 27, "net_absence": 14, "drift_per_commit": 0.73, "drift_per_touching_commit": 0.87, "eroding_commits": 15, "repairing_commits": 2, "conformance_changing_commits": 17, "source_touching_commits": 47, "similarity_start": 74.19, "similarity_end": 51.61, "similarity_min": 51.61, "direction": "divergence-led"}
- {"project": "covid-vaccination-system", "commits": 12, "divergences_start": 67, "divergences_end": 67, "absences_start": 56, "absences_end": 56, "net_divergence": 0, "net_absence": 0, "drift_per_commit": 0, "drift_per_touching_commit": 0, "eroding_commits": 0, "repairing_commits": 0, "conformance_changing_commits": 0, "source_touching_commits": 4, "similarity_start": 66.2, "similarity_end": 66.2, "similarity_min": 66.2, "direction": "stable"}
- {"project": "discordbotrpg", "commits": 104, "divergences_start": 313, "divergences_end": 498, "absences_start": 106, "absences_end": 110, "net_divergence": 185, "net_absence": 4, "drift_per_commit": 1.83, "drift_per_touching_commit": 3.05, "eroding_commits": 11, "repairing_commits": 0, "conformance_changing_commits": 12, "source_touching_commits": 62, "similarity_start": 33.33, "similarity_end": 34.04, "similarity_min": 33.33, "direction": "divergence-led"}
- {"project": "django-business-logic", "commits": 27, "divergences_start": 137, "divergences_end": 138, "absences_start": 55, "absences_end": 55, "net_divergence": 1, "net_absence": 0, "drift_per_commit": 0.04, "drift_per_touching_commit": 0.14, "eroding_commits": 1, "repairing_commits": 0, "conformance_changing_commits": 1, "source_touching_commits": 7, "similarity_start": 33.87, "similarity_end": 33.87, "similarity_min": 33.87, "direction": "divergence-led"}
- {"project": "fire-app-builder", "commits": 18, "divergences_start": 610, "divergences_end": 751, "absences_start": 175, "absences_end": 208, "net_divergence": 141, "net_absence": 33, "drift_per_commit": 10.24, "drift_per_touching_commit": 10.24, "eroding_commits": 3, "repairing_commits": 1, "conformance_changing_commits": 4, "source_touching_commits": 17, "similarity_start": 43.96, "similarity_end": 40.48, "similarity_min": 40.48, "direction": "divergence-led"}
- {"project": "forma-tech", "commits": 10, "divergences_start": 124, "divergences_end": 148, "absences_start": 57, "absences_end": 67, "net_divergence": 24, "net_absence": 10, "drift_per_commit": 3.78, "drift_per_touching_commit": 5.67, "eroding_commits": 5, "repairing_commits": 0, "conformance_changing_commits": 5, "source_touching_commits": 6, "similarity_start": 22.73, "similarity_end": 20.78, "similarity_min": 20.78, "direction": "divergence-led"}
- {"project": "formula1-fisica", "commits": 37, "divergences_start": 6, "divergences_end": 9, "absences_start": 21, "absences_end": 21, "net_divergence": 3, "net_absence": 0, "drift_per_commit": 0.08, "drift_per_touching_commit": 0.43, "eroding_commits": 3, "repairing_commits": 0, "conformance_changing_commits": 3, "source_touching_commits": 7, "similarity_start": 64.71, "similarity_end": 64.71, "similarity_min": 64.71, "direction": "divergence-led"}
- {"project": "galaxy-data-mines", "commits": 19, "divergences_start": 16, "divergences_end": 18, "absences_start": 25, "absences_end": 26, "net_divergence": 2, "net_absence": 1, "drift_per_commit": 0.17, "drift_per_touching_commit": 0.33, "eroding_commits": 2, "repairing_commits": 0, "conformance_changing_commits": 2, "source_touching_commits": 9, "similarity_start": 86.89, "similarity_end": 85.25, "similarity_min": 85.25, "direction": "divergence-led"}
- {"project": "gamespark", "commits": 13, "divergences_start": 45, "divergences_end": 45, "absences_start": 64, "absences_end": 64, "net_divergence": 0, "net_absence": 0, "drift_per_commit": 0, "drift_per_touching_commit": 0, "eroding_commits": 0, "repairing_commits": 0, "conformance_changing_commits": 0, "source_touching_commits": 1, "similarity_start": 91.72, "similarity_end": 91.72, "similarity_min": 91.72, "direction": "stable"}
- {"project": "gdxiris", "commits": 24, "divergences_start": 3, "divergences_end": 14, "absences_start": 8, "absences_end": 7, "net_divergence": 11, "net_absence": -1, "drift_per_commit": 0.43, "drift_per_touching_commit": 0.83, "eroding_commits": 3, "repairing_commits": 0, "conformance_changing_commits": 4, "source_touching_commits": 12, "similarity_start": 27.27, "similarity_end": 22.22, "similarity_min": 22.22, "direction": "divergence-led"}
- {"project": "genetic-algorithm", "commits": 56, "divergences_start": 60, "divergences_end": 125, "absences_start": 49, "absences_end": 53, "net_divergence": 65, "net_absence": 4, "drift_per_commit": 1.25, "drift_per_touching_commit": 1.3, "eroding_commits": 19, "repairing_commits": 3, "conformance_changing_commits": 26, "source_touching_commits": 53, "similarity_start": 53.06, "similarity_end": 40.0, "similarity_min": 40.0, "direction": "divergence-led"}
- {"project": "gestvae", "commits": 150, "divergences_start": 26, "divergences_end": 144, "absences_start": 32, "absences_end": 49, "net_divergence": 118, "net_absence": 17, "drift_per_commit": 0.91, "drift_per_touching_commit": 1.82, "eroding_commits": 45, "repairing_commits": 4, "conformance_changing_commits": 51, "source_touching_commits": 74, "similarity_start": 22.73, "similarity_end": 30.0, "similarity_min": 22.73, "direction": "divergence-led"}
- {"project": "hotelaurademallorca", "commits": 150, "divergences_start": 66, "divergences_end": 75, "absences_start": 10, "absences_end": 15, "net_divergence": 9, "net_absence": 5, "drift_per_commit": 0.09, "drift_per_touching_commit": 0.09, "eroding_commits": 7, "repairing_commits": 0, "conformance_changing_commits": 7, "source_touching_commits": 149, "similarity_start": 92.31, "similarity_end": 82.69, "similarity_min": 82.69, "direction": "divergence-led"}
- {"project": "hydgl", "commits": 72, "divergences_start": 256, "divergences_end": 217, "absences_start": 24, "absences_end": 25, "net_divergence": -39, "net_absence": 1, "drift_per_commit": -0.54, "drift_per_touching_commit": -0.54, "eroding_commits": 2, "repairing_commits": 1, "conformance_changing_commits": 3, "source_touching_commits": 71, "similarity_start": 74.55, "similarity_end": 72.22, "similarity_min": 72.22, "direction": "absence-led"}
- {"project": "ing-sw-2019-mauri-murriero-ostrovan", "commits": 114, "divergences_start": 5, "divergences_end": 113, "absences_start": 37, "absences_end": 44, "net_divergence": 108, "net_absence": 7, "drift_per_commit": 1.02, "drift_per_touching_commit": 1.95, "eroding_commits": 29, "repairing_commits": 8, "conformance_changing_commits": 37, "source_touching_commits": 59, "similarity_start": 95.83, "similarity_end": 86.11, "similarity_min": 0.0, "direction": "divergence-led"}
- {"project": "is1-project-audio-streaming-system", "commits": 9, "divergences_start": 133, "divergences_end": 133, "absences_start": 20, "absences_end": 20, "net_divergence": 0, "net_absence": 0, "drift_per_commit": 0, "drift_per_touching_commit": 0, "eroding_commits": 0, "repairing_commits": 0, "conformance_changing_commits": 0, "source_touching_commits": 8, "similarity_start": 51.85, "similarity_end": 51.85, "similarity_min": 51.85, "direction": "stable"}
- {"project": "library-web-api", "commits": 22, "divergences_start": 17, "divergences_end": 17, "absences_start": 30, "absences_end": 30, "net_divergence": 0, "net_absence": 0, "drift_per_commit": 0, "drift_per_touching_commit": 0, "eroding_commits": 0, "repairing_commits": 0, "conformance_changing_commits": 0, "source_touching_commits": 5, "similarity_start": 19.05, "similarity_end": 19.05, "similarity_min": 19.05, "direction": "stable"}
- {"project": "meeting-room-display", "commits": 16, "divergences_start": 152, "divergences_end": 154, "absences_start": 60, "absences_end": 60, "net_divergence": 2, "net_absence": 0, "drift_per_commit": 0.13, "drift_per_touching_commit": 0.33, "eroding_commits": 1, "repairing_commits": 0, "conformance_changing_commits": 1, "source_touching_commits": 6, "similarity_start": 64.6, "similarity_end": 64.6, "similarity_min": 64.6, "direction": "divergence-led"}
- {"project": "minesweeper", "commits": 98, "divergences_start": 26, "divergences_end": 57, "absences_start": 8, "absences_end": 8, "net_divergence": 31, "net_absence": 0, "drift_per_commit": 0.32, "drift_per_touching_commit": 0.32, "eroding_commits": 13, "repairing_commits": 1, "conformance_changing_commits": 15, "source_touching_commits": 97, "similarity_start": 69.23, "similarity_end": 69.23, "similarity_min": 64.71, "direction": "divergence-led"}
- {"project": "model-wolf-sheep", "commits": 16, "divergences_start": 35, "divergences_end": 33, "absences_start": 9, "absences_end": 9, "net_divergence": -2, "net_absence": 0, "drift_per_commit": -0.13, "drift_per_touching_commit": -0.33, "eroding_commits": 0, "repairing_commits": 1, "conformance_changing_commits": 1, "source_touching_commits": 6, "similarity_start": 66.67, "similarity_end": 66.67, "similarity_min": 66.67, "direction": "converging"}
- {"project": "mschartextension", "commits": 30, "divergences_start": 118, "divergences_end": 189, "absences_start": 22, "absences_end": 22, "net_divergence": 71, "net_absence": 0, "drift_per_commit": 2.45, "drift_per_touching_commit": 3.74, "eroding_commits": 9, "repairing_commits": 1, "conformance_changing_commits": 12, "source_touching_commits": 19, "similarity_start": 38.1, "similarity_end": 38.1, "similarity_min": 38.1, "direction": "divergence-led"}
- {"project": "open-market", "commits": 58, "divergences_start": 62, "divergences_end": 98, "absences_start": 10, "absences_end": 10, "net_divergence": 36, "net_absence": 0, "drift_per_commit": 0.63, "drift_per_touching_commit": 0.63, "eroding_commits": 12, "repairing_commits": 2, "conformance_changing_commits": 15, "source_touching_commits": 57, "similarity_start": 80.0, "similarity_end": 80.0, "similarity_min": 80.0, "direction": "divergence-led"}
- {"project": "openpose-unity-plugin", "commits": 16, "divergences_start": 146, "divergences_end": 152, "absences_start": 22, "absences_end": 22, "net_divergence": 6, "net_absence": 0, "drift_per_commit": 0.4, "drift_per_touching_commit": 0.55, "eroding_commits": 2, "repairing_commits": 0, "conformance_changing_commits": 3, "source_touching_commits": 11, "similarity_start": 60.0, "similarity_end": 60.0, "similarity_min": 60.0, "direction": "divergence-led"}
- {"project": "pbl03-dut-dk88", "commits": 36, "divergences_start": 33, "divergences_end": 58, "absences_start": 44, "absences_end": 60, "net_divergence": 25, "net_absence": 16, "drift_per_commit": 1.17, "drift_per_touching_commit": 4.1, "eroding_commits": 5, "repairing_commits": 2, "conformance_changing_commits": 7, "source_touching_commits": 10, "similarity_start": 33.33, "similarity_end": 34.38, "similarity_min": 28.21, "direction": "divergence-led"}
- {"project": "poker-bot-deep-rl", "commits": 81, "divergences_start": 51, "divergences_end": 99, "absences_start": 55, "absences_end": 55, "net_divergence": 48, "net_absence": 0, "drift_per_commit": 0.6, "drift_per_touching_commit": 0.6, "eroding_commits": 9, "repairing_commits": 3, "conformance_changing_commits": 13, "source_touching_commits": 80, "similarity_start": 44.83, "similarity_end": 44.83, "similarity_min": 44.83, "direction": "divergence-led"}
- {"project": "preprocessinglayer-nordjyske", "commits": 60, "divergences_start": 116, "divergences_end": 110, "absences_start": 10, "absences_end": 15, "net_divergence": -6, "net_absence": 5, "drift_per_commit": -0.02, "drift_per_touching_commit": -0.02, "eroding_commits": 3, "repairing_commits": 1, "conformance_changing_commits": 4, "source_touching_commits": 58, "similarity_start": 95.86, "similarity_end": 92.41, "similarity_min": 92.41, "direction": "absence-led"}
- {"project": "prism-php", "commits": 67, "divergences_start": 54, "divergences_end": 55, "absences_start": 23, "absences_end": 25, "net_divergence": 1, "net_absence": 2, "drift_per_commit": 0.05, "drift_per_touching_commit": 0.05, "eroding_commits": 5, "repairing_commits": 1, "conformance_changing_commits": 8, "source_touching_commits": 66, "similarity_start": 84.21, "similarity_end": 78.95, "similarity_min": 78.95, "direction": "absence-led"}
- {"project": "projet-cy-books", "commits": 48, "divergences_start": 220, "divergences_end": 236, "absences_start": 71, "absences_end": 71, "net_divergence": 16, "net_absence": 0, "drift_per_commit": 0.34, "drift_per_touching_commit": 0.67, "eroding_commits": 4, "repairing_commits": 2, "conformance_changing_commits": 7, "source_touching_commits": 24, "similarity_start": 47.47, "similarity_end": 47.47, "similarity_min": 47.47, "direction": "divergence-led"}
- {"project": "projet-hotel", "commits": 18, "divergences_start": 188, "divergences_end": 188, "absences_start": 18, "absences_end": 20, "net_divergence": 0, "net_absence": 2, "drift_per_commit": 0.12, "drift_per_touching_commit": 0.15, "eroding_commits": 4, "repairing_commits": 2, "conformance_changing_commits": 8, "source_touching_commits": 13, "similarity_start": 65.22, "similarity_end": 60.87, "similarity_min": 60.87, "direction": "absence-led"}
- {"project": "rdf4node", "commits": 150, "divergences_start": 84, "divergences_end": 116, "absences_start": 39, "absences_end": 37, "net_divergence": 32, "net_absence": -2, "drift_per_commit": 0.2, "drift_per_touching_commit": 0.2, "eroding_commits": 13, "repairing_commits": 4, "conformance_changing_commits": 19, "source_touching_commits": 149, "similarity_start": 39.66, "similarity_end": 43.1, "similarity_min": 39.66, "direction": "divergence-led"}
- {"project": "scs-simulation-of-insulin-pump", "commits": 26, "divergences_start": 292, "divergences_end": 292, "absences_start": 44, "absences_end": 44, "net_divergence": 0, "net_absence": 0, "drift_per_commit": 0, "drift_per_touching_commit": 0, "eroding_commits": 0, "repairing_commits": 0, "conformance_changing_commits": 0, "source_touching_commits": 25, "similarity_start": 15.38, "similarity_end": 15.38, "similarity_min": 15.38, "direction": "stable"}
- {"project": "sistema-bancario", "commits": 25, "divergences_start": 47, "divergences_end": 47, "absences_start": 5, "absences_end": 5, "net_divergence": 0, "net_absence": 0, "drift_per_commit": 0, "drift_per_touching_commit": 0, "eroding_commits": 0, "repairing_commits": 0, "conformance_changing_commits": 0, "source_touching_commits": 8, "similarity_start": 90.0, "similarity_end": 90.0, "similarity_min": 90.0, "direction": "stable"}
- {"project": "soulland", "commits": 93, "divergences_start": 9, "divergences_end": 71, "absences_start": 5, "absences_end": 5, "net_divergence": 62, "net_absence": 0, "drift_per_commit": 0.67, "drift_per_touching_commit": 1.17, "eroding_commits": 22, "repairing_commits": 8, "conformance_changing_commits": 31, "source_touching_commits": 53, "similarity_start": 91.67, "similarity_end": 91.67, "similarity_min": 83.33, "direction": "divergence-led"}
- {"project": "spring6plus", "commits": 38, "divergences_start": 81, "divergences_end": 118, "absences_start": 10, "absences_end": 10, "net_divergence": 37, "net_absence": 0, "drift_per_commit": 1, "drift_per_touching_commit": 4.11, "eroding_commits": 3, "repairing_commits": 0, "conformance_changing_commits": 3, "source_touching_commits": 9, "similarity_start": 88.41, "similarity_end": 88.41, "similarity_min": 88.41, "direction": "divergence-led"}
- {"project": "tankman", "commits": 37, "divergences_start": 125, "divergences_end": 98, "absences_start": 56, "absences_end": 60, "net_divergence": -27, "net_absence": 4, "drift_per_commit": -0.64, "drift_per_touching_commit": -0.79, "eroding_commits": 6, "repairing_commits": 1, "conformance_changing_commits": 8, "source_touching_commits": 29, "similarity_start": 45.12, "similarity_end": 42.68, "similarity_min": 42.68, "direction": "absence-led"}
- {"project": "translator", "commits": 12, "divergences_start": 29, "divergences_end": 36, "absences_start": 10, "absences_end": 10, "net_divergence": 7, "net_absence": 0, "drift_per_commit": 0.64, "drift_per_touching_commit": 2.33, "eroding_commits": 1, "repairing_commits": 0, "conformance_changing_commits": 2, "source_touching_commits": 3, "similarity_start": 79.07, "similarity_end": 79.07, "similarity_min": 79.07, "direction": "divergence-led"}
- {"project": "usms-web", "commits": 27, "divergences_start": 50, "divergences_end": 53, "absences_start": 27, "absences_end": 27, "net_divergence": 3, "net_absence": 0, "drift_per_commit": 0.12, "drift_per_touching_commit": 0.5, "eroding_commits": 2, "repairing_commits": 0, "conformance_changing_commits": 2, "source_touching_commits": 6, "similarity_start": 20.59, "similarity_end": 20.59, "similarity_min": 20.59, "direction": "divergence-led"}
- {"project": "vars-annotation", "commits": 150, "divergences_start": 430, "divergences_end": 466, "absences_start": 19, "absences_end": 17, "net_divergence": 36, "net_absence": -2, "drift_per_commit": 0.23, "drift_per_touching_commit": 0.23, "eroding_commits": 26, "repairing_commits": 3, "conformance_changing_commits": 31, "source_touching_commits": 148, "similarity_start": 65.38, "similarity_end": 65.38, "similarity_min": 65.38, "direction": "divergence-led"}
- {"project": "vectorx", "commits": 61, "divergences_start": 75, "divergences_end": 100, "absences_start": 35, "absences_end": 35, "net_divergence": 25, "net_absence": 0, "drift_per_commit": 0.42, "drift_per_touching_commit": 0.83, "eroding_commits": 10, "repairing_commits": 0, "conformance_changing_commits": 11, "source_touching_commits": 30, "similarity_start": 85.29, "similarity_end": 85.29, "similarity_min": 85.29, "direction": "divergence-led"}
- {"project": "virtualq-final-version", "commits": 4, "divergences_start": 72, "divergences_end": 74, "absences_start": 137, "absences_end": 137, "net_divergence": 2, "net_absence": 0, "drift_per_commit": 0.67, "drift_per_touching_commit": 0.67, "eroding_commits": 1, "repairing_commits": 0, "conformance_changing_commits": 1, "source_touching_commits": 3, "similarity_start": 10.77, "similarity_end": 10.77, "similarity_min": 10.77, "direction": "divergence-led"}
- {"project": "vscode-nativescript-extend", "commits": 126, "divergences_start": 30, "divergences_end": 37, "absences_start": 14, "absences_end": 14, "net_divergence": 7, "net_absence": 0, "drift_per_commit": 0.06, "drift_per_touching_commit": 0.21, "eroding_commits": 4, "repairing_commits": 1, "conformance_changing_commits": 5, "source_touching_commits": 34, "similarity_start": 79.71, "similarity_end": 79.71, "similarity_min": 79.71, "direction": "divergence-led"}
- {"project": "xtask", "commits": 24, "divergences_start": 270, "divergences_end": 331, "absences_start": 1, "absences_end": 2, "net_divergence": 61, "net_absence": 1, "drift_per_commit": 2.7, "drift_per_touching_commit": 2.7, "eroding_commits": 7, "repairing_commits": 0, "conformance_changing_commits": 7, "source_touching_commits": 23, "similarity_start": 97.87, "similarity_end": 95.74, "similarity_min": 95.74, "direction": "divergence-led"}

## Survival
- androuter {"designed_elements": 8, "conforming_at_freeze": 0, "deviating_at_freeze": 8, "deviated_during_window": 0, "survival_at_end": null, "half_life_commits": null, "half_life_censored_beyond": 34, "first_deviations": {}}
  curve: []
- angular-fullstack-pro-starter {"designed_elements": 8, "conforming_at_freeze": 0, "deviating_at_freeze": 8, "deviated_during_window": 0, "survival_at_end": null, "half_life_commits": null, "half_life_censored_beyond": 13, "first_deviations": {}}
  curve: []
- artvance {"designed_elements": 15, "conforming_at_freeze": 0, "deviating_at_freeze": 15, "deviated_during_window": 0, "survival_at_end": null, "half_life_commits": null, "half_life_censored_beyond": 24, "first_deviations": {}}
  curve: []
- astrominer {"designed_elements": 15, "conforming_at_freeze": 0, "deviating_at_freeze": 15, "deviated_during_window": 0, "survival_at_end": null, "half_life_commits": null, "half_life_censored_beyond": 93, "first_deviations": {}}
  curve: []
- bankthread {"designed_elements": 5, "conforming_at_freeze": 0, "deviating_at_freeze": 5, "deviated_during_window": 0, "survival_at_end": null, "half_life_commits": null, "half_life_censored_beyond": 6, "first_deviations": {}}
  curve: []
- banquale {"designed_elements": 16, "conforming_at_freeze": 5, "deviating_at_freeze": 11, "deviated_during_window": 1, "survival_at_end": 0.8, "half_life_commits": null, "half_life_censored_beyond": 33, "first_deviations": {"Message": 14}}
  curve: [{'commit': 14, 'survival': 0.8, 'at_risk': 5}]
- board-game {"designed_elements": 23, "conforming_at_freeze": 3, "deviating_at_freeze": 20, "deviated_during_window": 0, "survival_at_end": 1, "half_life_commits": null, "half_life_censored_beyond": 10, "first_deviations": {}}
  curve: []
- codearteng-diagnostics {"designed_elements": 11, "conforming_at_freeze": 1, "deviating_at_freeze": 10, "deviated_during_window": 0, "survival_at_end": 1, "half_life_commits": null, "half_life_censored_beyond": 11, "first_deviations": {}}
  curve: []
- codingame-puzzles-stats-library {"designed_elements": 10, "conforming_at_freeze": 0, "deviating_at_freeze": 10, "deviated_during_window": 0, "survival_at_end": null, "half_life_commits": null, "half_life_censored_beyond": 149, "first_deviations": {}}
  curve: []
- commandandcontrolsystem-lds {"designed_elements": 7, "conforming_at_freeze": 0, "deviating_at_freeze": 7, "deviated_during_window": 0, "survival_at_end": null, "half_life_commits": null, "half_life_censored_beyond": 12, "first_deviations": {}}
  curve: []
- cookpot {"designed_elements": 20, "conforming_at_freeze": 6, "deviating_at_freeze": 14, "deviated_during_window": 4, "survival_at_end": 0.33, "half_life_commits": 50, "half_life_censored_beyond": null, "first_deviations": {"AccessManager": 4, "DishManager": 5, "CookingUtensil": 50, "Search": 50}}
  curve: [{'commit': 4, 'survival': 0.83, 'at_risk': 6}, {'commit': 5, 'survival': 0.67, 'at_risk': 5}, {'commit': 50, 'survival': 0.33, 'at_risk': 4}]
- covid-vaccination-system {"designed_elements": 19, "conforming_at_freeze": 0, "deviating_at_freeze": 19, "deviated_during_window": 0, "survival_at_end": null, "half_life_commits": null, "half_life_censored_beyond": 11, "first_deviations": {}}
  curve: []
- discordbotrpg {"designed_elements": 22, "conforming_at_freeze": 0, "deviating_at_freeze": 22, "deviated_during_window": 0, "survival_at_end": null, "half_life_commits": null, "half_life_censored_beyond": 103, "first_deviations": {}}
  curve: []
- django-business-logic {"designed_elements": 18, "conforming_at_freeze": 0, "deviating_at_freeze": 18, "deviated_during_window": 0, "survival_at_end": null, "half_life_commits": null, "half_life_censored_beyond": 26, "first_deviations": {}}
  curve: []
- fire-app-builder {"designed_elements": 114, "conforming_at_freeze": 3, "deviating_at_freeze": 111, "deviated_during_window": 1, "survival_at_end": 0.67, "half_life_commits": null, "half_life_censored_beyond": 17, "first_deviations": {"ItemViewClickedListener": 7}}
  curve: [{'commit': 7, 'survival': 0.67, 'at_risk': 3}]
- forma-tech {"designed_elements": 9, "conforming_at_freeze": 0, "deviating_at_freeze": 9, "deviated_during_window": 0, "survival_at_end": null, "half_life_commits": null, "half_life_censored_beyond": 9, "first_deviations": {}}
  curve: []
- formula1-fisica {"designed_elements": 9, "conforming_at_freeze": 2, "deviating_at_freeze": 7, "deviated_during_window": 0, "survival_at_end": 1, "half_life_commits": null, "half_life_censored_beyond": 36, "first_deviations": {}}
  curve: []
- galaxy-data-mines {"designed_elements": 6, "conforming_at_freeze": 0, "deviating_at_freeze": 6, "deviated_during_window": 0, "survival_at_end": null, "half_life_commits": null, "half_life_censored_beyond": 18, "first_deviations": {}}
  curve: []
- gamespark {"designed_elements": 53, "conforming_at_freeze": 32, "deviating_at_freeze": 21, "deviated_during_window": 0, "survival_at_end": 1, "half_life_commits": null, "half_life_censored_beyond": 12, "first_deviations": {}}
  curve: []
- gdxiris {"designed_elements": 6, "conforming_at_freeze": 1, "deviating_at_freeze": 5, "deviated_during_window": 1, "survival_at_end": 0, "half_life_commits": 1, "half_life_censored_beyond": null, "first_deviations": {"EventPrototype": 1}}
  curve: [{'commit': 1, 'survival': 0, 'at_risk': 1}]
- genetic-algorithm {"designed_elements": 19, "conforming_at_freeze": 4, "deviating_at_freeze": 15, "deviated_during_window": 4, "survival_at_end": 0, "half_life_commits": 2, "half_life_censored_beyond": null, "first_deviations": {"QxShapeTransformationPanel": 1, "ImageCloningProblem": 2, "ShapeTransformationProblem": 2, "QxImageCloningPanel": 6}}
  curve: [{'commit': 1, 'survival': 0.75, 'at_risk': 4}, {'commit': 2, 'survival': 0.25, 'at_risk': 3}, {'commit': 6, 'survival': 0, 'at_risk': 1}]
- gestvae {"designed_elements": 12, "conforming_at_freeze": 0, "deviating_at_freeze": 12, "deviated_during_window": 0, "survival_at_end": null, "half_life_commits": null, "half_life_censored_beyond": 149, "first_deviations": {}}
  curve: []
- hotelaurademallorca {"designed_elements": 13, "conforming_at_freeze": 0, "deviating_at_freeze": 13, "deviated_during_window": 0, "survival_at_end": null, "half_life_commits": null, "half_life_censored_beyond": 149, "first_deviations": {}}
  curve: []
- hydgl {"designed_elements": 24, "conforming_at_freeze": 11, "deviating_at_freeze": 13, "deviated_during_window": 0, "survival_at_end": 1, "half_life_commits": null, "half_life_censored_beyond": 71, "first_deviations": {}}
  curve: []
- ing-sw-2019-mauri-murriero-ostrovan {"designed_elements": 16, "conforming_at_freeze": 11, "deviating_at_freeze": 5, "deviated_during_window": 11, "survival_at_end": 0, "half_life_commits": 13, "half_life_censored_beyond": null, "first_deviations": {"Deck": 3, "Inventory": 3, "KillScoreBoard": 3, "Player": 7, "Square": 10, "GameBoard": 13, "Map": 17, "Direction": 22, "Decks": 63, "Grabbable": 63, "PowerUpCard": 63}}
  curve: [{'commit': 3, 'survival': 0.73, 'at_risk': 11}, {'commit': 7, 'survival': 0.64, 'at_risk': 8}, {'commit': 10, 'survival': 0.55, 'at_risk': 7}, {'commit': 13, 'survival': 0.45, 'at_risk': 6}, {'commit': 17, 'survival': 0.36, 'at_risk': 5}, {'commit': 22, 'survival': 0.27, 'at_risk': 4}, {'commit': 63, 'survival': 0, 'at_risk': 3}]
- is1-project-audio-streaming-system {"designed_elements": 10, "conforming_at_freeze": 0, "deviating_at_freeze": 10, "deviated_during_window": 0, "survival_at_end": null, "half_life_commits": null, "half_life_censored_beyond": 8, "first_deviations": {}}
  curve: []
- library-web-api {"designed_elements": 12, "conforming_at_freeze": 0, "deviating_at_freeze": 12, "deviated_during_window": 0, "survival_at_end": null, "half_life_commits": null, "half_life_censored_beyond": 21, "first_deviations": {}}
  curve: []
- meeting-room-display {"designed_elements": 25, "conforming_at_freeze": 1, "deviating_at_freeze": 24, "deviated_during_window": 0, "survival_at_end": 1, "half_life_commits": null, "half_life_censored_beyond": 15, "first_deviations": {}}
  curve: []
- minesweeper {"designed_elements": 6, "conforming_at_freeze": 1, "deviating_at_freeze": 5, "deviated_during_window": 0, "survival_at_end": 1, "half_life_commits": null, "half_life_censored_beyond": 97, "first_deviations": {}}
  curve: []
- model-wolf-sheep {"designed_elements": 8, "conforming_at_freeze": 0, "deviating_at_freeze": 8, "deviated_during_window": 0, "survival_at_end": null, "half_life_commits": null, "half_life_censored_beyond": 15, "first_deviations": {}}
  curve: []
- mschartextension {"designed_elements": 18, "conforming_at_freeze": 0, "deviating_at_freeze": 18, "deviated_during_window": 0, "survival_at_end": null, "half_life_commits": null, "half_life_censored_beyond": 29, "first_deviations": {}}
  curve: []
- open-market {"designed_elements": 12, "conforming_at_freeze": 2, "deviating_at_freeze": 10, "deviated_during_window": 0, "survival_at_end": 1, "half_life_commits": null, "half_life_censored_beyond": 57, "first_deviations": {}}
  curve: []
- openpose-unity-plugin {"designed_elements": 10, "conforming_at_freeze": 0, "deviating_at_freeze": 10, "deviated_during_window": 0, "survival_at_end": null, "half_life_commits": null, "half_life_censored_beyond": 15, "first_deviations": {}}
  curve: []
- pbl03-dut-dk88 {"designed_elements": 9, "conforming_at_freeze": 0, "deviating_at_freeze": 9, "deviated_during_window": 0, "survival_at_end": null, "half_life_commits": null, "half_life_censored_beyond": 35, "first_deviations": {}}
  curve: []
- poker-bot-deep-rl {"designed_elements": 12, "conforming_at_freeze": 0, "deviating_at_freeze": 12, "deviated_during_window": 0, "survival_at_end": null, "half_life_commits": null, "half_life_censored_beyond": 80, "first_deviations": {}}
  curve: []
- preprocessinglayer-nordjyske {"designed_elements": 21, "conforming_at_freeze": 3, "deviating_at_freeze": 18, "deviated_during_window": 0, "survival_at_end": 1, "half_life_commits": null, "half_life_censored_beyond": 59, "first_deviations": {}}
  curve: []
- prism-php {"designed_elements": 12, "conforming_at_freeze": 1, "deviating_at_freeze": 11, "deviated_during_window": 0, "survival_at_end": 1, "half_life_commits": null, "half_life_censored_beyond": 66, "first_deviations": {}}
  curve: []
- projet-cy-books {"designed_elements": 23, "conforming_at_freeze": 0, "deviating_at_freeze": 23, "deviated_during_window": 0, "survival_at_end": null, "half_life_commits": null, "half_life_censored_beyond": 47, "first_deviations": {}}
  curve: []
- projet-hotel {"designed_elements": 14, "conforming_at_freeze": 0, "deviating_at_freeze": 14, "deviated_during_window": 0, "survival_at_end": null, "half_life_commits": null, "half_life_censored_beyond": 17, "first_deviations": {}}
  curve: []
- rdf4node {"designed_elements": 20, "conforming_at_freeze": 2, "deviating_at_freeze": 18, "deviated_during_window": 0, "survival_at_end": 1, "half_life_commits": null, "half_life_censored_beyond": 149, "first_deviations": {}}
  curve: []
- scs-simulation-of-insulin-pump {"designed_elements": 7, "conforming_at_freeze": 0, "deviating_at_freeze": 7, "deviated_during_window": 0, "survival_at_end": null, "half_life_commits": null, "half_life_censored_beyond": 25, "first_deviations": {}}
  curve: []
- sistema-bancario {"designed_elements": 8, "conforming_at_freeze": 1, "deviating_at_freeze": 7, "deviated_during_window": 0, "survival_at_end": 1, "half_life_commits": null, "half_life_censored_beyond": 24, "first_deviations": {}}
  curve: []
- soulland {"designed_elements": 5, "conforming_at_freeze": 3, "deviating_at_freeze": 2, "deviated_during_window": 3, "survival_at_end": 0, "half_life_commits": 7, "half_life_censored_beyond": null, "first_deviations": {"Logger": 3, "Inventory": 7, "World": 7}}
  curve: [{'commit': 3, 'survival': 0.67, 'at_risk': 3}, {'commit': 7, 'survival': 0, 'at_risk': 2}]
- spring6plus {"designed_elements": 24, "conforming_at_freeze": 8, "deviating_at_freeze": 16, "deviated_during_window": 0, "survival_at_end": 1, "half_life_commits": null, "half_life_censored_beyond": 37, "first_deviations": {}}
  curve: []
- tankman {"designed_elements": 22, "conforming_at_freeze": 0, "deviating_at_freeze": 22, "deviated_during_window": 0, "survival_at_end": null, "half_life_commits": null, "half_life_censored_beyond": 36, "first_deviations": {}}
  curve: []
- translator {"designed_elements": 12, "conforming_at_freeze": 2, "deviating_at_freeze": 10, "deviated_during_window": 1, "survival_at_end": 0.5, "half_life_commits": 3, "half_life_censored_beyond": null, "first_deviations": {"Translator": 3}}
  curve: [{'commit': 3, 'survival': 0.5, 'at_risk': 2}]
- usms-web {"designed_elements": 7, "conforming_at_freeze": 0, "deviating_at_freeze": 7, "deviated_during_window": 0, "survival_at_end": null, "half_life_commits": null, "half_life_censored_beyond": 26, "first_deviations": {}}
  curve: []
- vars-annotation {"designed_elements": 16, "conforming_at_freeze": 3, "deviating_at_freeze": 13, "deviated_during_window": 0, "survival_at_end": 1, "half_life_commits": null, "half_life_censored_beyond": 149, "first_deviations": {}}
  curve: []
- vectorx {"designed_elements": 10, "conforming_at_freeze": 6, "deviating_at_freeze": 4, "deviated_during_window": 0, "survival_at_end": 1, "half_life_commits": null, "half_life_censored_beyond": 60, "first_deviations": {}}
  curve: []
- virtualq-final-version {"designed_elements": 13, "conforming_at_freeze": 0, "deviating_at_freeze": 13, "deviated_during_window": 0, "survival_at_end": null, "half_life_commits": null, "half_life_censored_beyond": 3, "first_deviations": {}}
  curve: []
- vscode-nativescript-extend {"designed_elements": 16, "conforming_at_freeze": 6, "deviating_at_freeze": 10, "deviated_during_window": 0, "survival_at_end": 1, "half_life_commits": null, "half_life_censored_beyond": 125, "first_deviations": {}}
  curve: []
- xtask {"designed_elements": 24, "conforming_at_freeze": 1, "deviating_at_freeze": 23, "deviated_during_window": 0, "survival_at_end": 1, "half_life_commits": null, "half_life_censored_beyond": 23, "first_deviations": {}}
  curve: []
- pooled: {'projects': 52, 'at_risk': 119, 'events': 26, 'half_life_commits': None, 'survival_at_end': 0.68}
