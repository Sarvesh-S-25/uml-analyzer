# What the numbers say

**`structural` is the most economical gate that missed nothing: it skipped 60.0% of runs and saved 0 tokens. Across projects its skip rate ranged from 13.0% to 95.0%.**

## Table 1 — What was studied

| | |
|---|---|
| Projects | 52 |
| Commits analysed | 2606 |
| Total analysis runs | 10424 |
| Gate policies compared | 4 |
| Can we measure misses? | Yes |

*52 projects and 2606 commits. Each commit was analysed once per gate policy, giving 10,424 runs in total. A full analysis was forced alongside every commit, so whenever a gate skipped a commit we can check whether it should have.*

## Table 2 — How each gate performed

| Gate | Runs | Re-analysed | Skipped | Skip rate | Missed | Miss rate | Tokens | Saved |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `always` | 2606 | 2606 | 0 | 0.0% [0%–0%] | 0 | 0.0% | 0 | — |
| `content` | 2606 | 1399 | 1207 | 46.0% [44%–48%] | 0 | 0.0% | 0 | 0 |
| `structural` | 2606 | 1049 | 1557 | 60.0% [58%–62%] | 0 | 0.0% | 0 | 0 |
| `isomorphism` | 2606 | 872 | 1734 | 67.0% [65%–68%] | 117 | 4.0% | 0 | 0 |

Row by row:

- **`always`** — Re-analysed all 2606 runs and spent 0 tokens. This is what the other gates are compared against.
- **`content`** — Skipped 1207 of 2606 runs (46.0%, between 44% and 48% if the study were repeated) and missed nothing. Of the 514 commits where conformance really changed, it re-analysed 100.0% (between 99% and 100%).
- **`structural`** — Skipped 1557 of 2606 runs (60.0%, between 58% and 62% if the study were repeated) and missed nothing. Of the 514 commits where conformance really changed, it re-analysed 100.0% (between 99% and 100%).
- **`isomorphism`** — Skipped 1734 of 2606 runs (67.0%, between 65% and 68% if the study were repeated) but missed 117 real conformance changes (4.0% of all runs). Of the 514 commits where conformance really changed, it re-analysed 93.0% (between 90% and 95%). A miss was corrected after a median of 2 commit(s).

*`structural` is the most economical gate that missed nothing: it skipped 60.0% of runs and saved 0 tokens. `isomorphism` is the cheapest option but not a free one: it skipped 67.0% of runs and missed 117 real changes. That is the trade the paper is about — quote its skip rate and its miss rate in the same sentence, always.*

## Table 3 — Did it work on every project?

Numbers below are for the `structural` gate.

| Project | Commits | Runs | Skip rate | Missed | Tokens saved | Drift/commit |
|---|---:|---:|---:|---:|---:|---:|
| androuter | 35 | 35 | 54.0% | 0 | 0 | 0.03 |
| angular-fullstack-pro-starter | 14 | 14 | 79.0% | 0 | 0 | 0 |
| artvance | 25 | 25 | 80.0% | 0 | 0 | 0.54 |
| astrominer | 94 | 94 | 13.0% | 0 | 0 | 5.24 |
| bankthread | 7 | 7 | 29.0% | 0 | 0 | 1.5 |
| banquale | 34 | 34 | 74.0% | 0 | 0 | 0.21 |
| board-game | 11 | 11 | 55.0% | 0 | 0 | -0.1 |
| codearteng-diagnostics | 12 | 12 | 42.0% | 0 | 0 | 1 |
| codingame-puzzles-stats-library | 150 | 150 | 66.0% | 0 | 0 | 0.44 |
| commandandcontrolsystem-lds | 13 | 13 | 62.0% | 0 | 0 | 0 |
| cookpot | 57 | 57 | 25.0% | 0 | 0 | 0.73 |
| covid-vaccination-system | 12 | 12 | 83.0% | 0 | 0 | 0 |
| discordbotrpg | 104 | 104 | 67.0% | 0 | 0 | 1.83 |
| django-business-logic | 27 | 27 | 93.0% | 0 | 0 | 0.04 |
| fire-app-builder | 18 | 18 | 61.0% | 0 | 0 | 10.24 |
| forma-tech | 10 | 10 | 30.0% | 0 | 0 | 3.78 |
| formula1-fisica | 37 | 37 | 81.0% | 0 | 0 | 0.08 |
| galaxy-data-mines | 19 | 19 | 63.0% | 0 | 0 | 0.17 |
| gamespark | 13 | 13 | 85.0% | 0 | 0 | 0 |
| gdxiris | 24 | 24 | 54.0% | 0 | 0 | 0.43 |
| genetic-algorithm | 56 | 56 | 23.0% | 0 | 0 | 1.25 |
| gestvae | 150 | 150 | 59.0% | 0 | 0 | 0.91 |
| hotelaurademallorca | 150 | 150 | 74.0% | 0 | 0 | 0.09 |
| hydgl | 72 | 72 | 82.0% | 0 | 0 | -0.54 |
| ing-sw-2019-mauri-murriero-ostrovan | 114 | 114 | 50.0% | 0 | 0 | 1.02 |
| is1-project-audio-streaming-system | 9 | 9 | 89.0% | 0 | 0 | 0 |
| library-web-api | 22 | 22 | 95.0% | 0 | 0 | 0 |
| meeting-room-display | 16 | 16 | 75.0% | 0 | 0 | 0.13 |
| minesweeper | 98 | 98 | 58.0% | 0 | 0 | 0.32 |
| model-wolf-sheep | 16 | 16 | 81.0% | 0 | 0 | -0.13 |
| mschartextension | 30 | 30 | 40.0% | 0 | 0 | 2.45 |
| open-market | 58 | 58 | 19.0% | 0 | 0 | 0.63 |
| openpose-unity-plugin | 16 | 16 | 69.0% | 0 | 0 | 0.4 |
| pbl03-dut-dk88 | 36 | 36 | 69.0% | 0 | 0 | 1.17 |
| poker-bot-deep-rl | 81 | 81 | 41.0% | 0 | 0 | 0.6 |
| preprocessinglayer-nordjyske | 60 | 60 | 80.0% | 0 | 0 | -0.02 |
| prism-php | 67 | 67 | 66.0% | 0 | 0 | 0.05 |
| projet-cy-books | 48 | 48 | 62.0% | 0 | 0 | 0.34 |
| projet-hotel | 18 | 18 | 39.0% | 0 | 0 | 0.12 |
| rdf4node | 150 | 150 | 46.0% | 0 | 0 | 0.2 |
| scs-simulation-of-insulin-pump | 26 | 26 | 92.0% | 0 | 0 | 0 |
| sistema-bancario | 25 | 25 | 88.0% | 0 | 0 | 0 |
| soulland | 93 | 93 | 56.0% | 0 | 0 | 0.67 |
| spring6plus | 38 | 38 | 76.0% | 0 | 0 | 1 |
| tankman | 37 | 37 | 54.0% | 0 | 0 | -0.64 |
| translator | 12 | 12 | 67.0% | 0 | 0 | 0.64 |
| usms-web | 27 | 27 | 81.0% | 0 | 0 | 0.12 |
| vars-annotation | 150 | 150 | 52.0% | 0 | 0 | 0.23 |
| vectorx | 61 | 61 | 61.0% | 0 | 0 | 0.42 |
| virtualq-final-version | 4 | 4 | 50.0% | 0 | 0 | 0.67 |
| vscode-nativescript-extend | 126 | 126 | 90.0% | 0 | 0 | 0.06 |
| xtask | 24 | 24 | 58.0% | 0 | 0 | 2.7 |

*With the `structural` gate, skip rates ranged from 13.0% to 95.0% across 52 projects. It missed nothing in any project. The gates do not rank the same way in every project (best gate is `content`, `isomorphism`, `structural` depending on the project). Say so explicitly rather than reporting only the pooled numbers. Too few runs to trust the rate in: bankthread, is1-project-audio-streaming-system, virtualq-final-version.*

### Every gate, project by project

| Project | Gate | Runs | Skipped | Skip rate | Missed | Tokens | Saved |
|---|---|---:|---:|---:|---:|---:|---:|
| androuter | `always` | 35 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 35 | 18 | 51.0% | 0 | 0 | 0 |
|  | `structural` | 35 | 19 | 54.0% | 0 | 0 | 0 |
|  | `isomorphism` | 35 | 20 | 57.0% | 0 | 0 | 0 |
| angular-fullstack-pro-starter | `always` | 14 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 14 | 11 | 79.0% | 0 | 0 | 0 |
|  | `structural` | 14 | 11 | 79.0% | 0 | 0 | 0 |
|  | `isomorphism` | 14 | 13 | 93.0% | 0 | 0 | 0 |
| artvance | `always` | 25 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 25 | 19 | 76.0% | 0 | 0 | 0 |
|  | `structural` | 25 | 20 | 80.0% | 0 | 0 | 0 |
|  | `isomorphism` | 25 | 21 | 84.0% | 6 | 0 | 0 |
| astrominer | `always` | 94 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 94 | 9 | 10.0% | 0 | 0 | 0 |
|  | `structural` | 94 | 12 | 13.0% | 0 | 0 | 0 |
|  | `isomorphism` | 94 | 13 | 14.0% | 0 | 0 | 0 |
| bankthread | `always` | 7 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 7 | 1 | 14.0% | 0 | 0 | 0 |
|  | `structural` | 7 | 2 | 29.0% | 0 | 0 | 0 |
|  | `isomorphism` | 7 | 2 | 29.0% | 0 | 0 | 0 |
| banquale | `always` | 34 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 34 | 22 | 65.0% | 0 | 0 | 0 |
|  | `structural` | 34 | 25 | 74.0% | 0 | 0 | 0 |
|  | `isomorphism` | 34 | 26 | 76.0% | 0 | 0 | 0 |
| board-game | `always` | 11 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 11 | 5 | 45.0% | 0 | 0 | 0 |
|  | `structural` | 11 | 6 | 55.0% | 0 | 0 | 0 |
|  | `isomorphism` | 11 | 8 | 73.0% | 0 | 0 | 0 |
| codearteng-diagnostics | `always` | 12 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 12 | 5 | 42.0% | 0 | 0 | 0 |
|  | `structural` | 12 | 5 | 42.0% | 0 | 0 | 0 |
|  | `isomorphism` | 12 | 6 | 50.0% | 0 | 0 | 0 |
| codingame-puzzles-stats-library | `always` | 150 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 150 | 92 | 61.0% | 0 | 0 | 0 |
|  | `structural` | 150 | 99 | 66.0% | 0 | 0 | 0 |
|  | `isomorphism` | 150 | 117 | 78.0% | 13 | 0 | 0 |
| commandandcontrolsystem-lds | `always` | 13 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 13 | 7 | 54.0% | 0 | 0 | 0 |
|  | `structural` | 13 | 8 | 62.0% | 0 | 0 | 0 |
|  | `isomorphism` | 13 | 8 | 62.0% | 0 | 0 | 0 |
| cookpot | `always` | 57 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 57 | 9 | 16.0% | 0 | 0 | 0 |
|  | `structural` | 57 | 14 | 25.0% | 0 | 0 | 0 |
|  | `isomorphism` | 57 | 20 | 35.0% | 1 | 0 | 0 |
| covid-vaccination-system | `always` | 12 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 12 | 8 | 67.0% | 0 | 0 | 0 |
|  | `structural` | 12 | 10 | 83.0% | 0 | 0 | 0 |
|  | `isomorphism` | 12 | 10 | 83.0% | 0 | 0 | 0 |
| discordbotrpg | `always` | 104 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 104 | 41 | 39.0% | 0 | 0 | 0 |
|  | `structural` | 104 | 70 | 67.0% | 0 | 0 | 0 |
|  | `isomorphism` | 104 | 70 | 67.0% | 0 | 0 | 0 |
| django-business-logic | `always` | 27 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 27 | 19 | 70.0% | 0 | 0 | 0 |
|  | `structural` | 27 | 25 | 93.0% | 0 | 0 | 0 |
|  | `isomorphism` | 27 | 25 | 93.0% | 0 | 0 | 0 |
| fire-app-builder | `always` | 18 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 18 | 11 | 61.0% | 0 | 0 | 0 |
|  | `structural` | 18 | 11 | 61.0% | 0 | 0 | 0 |
|  | `isomorphism` | 18 | 11 | 61.0% | 0 | 0 | 0 |
| forma-tech | `always` | 10 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 10 | 3 | 30.0% | 0 | 0 | 0 |
|  | `structural` | 10 | 3 | 30.0% | 0 | 0 | 0 |
|  | `isomorphism` | 10 | 3 | 30.0% | 0 | 0 | 0 |
| formula1-fisica | `always` | 37 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 37 | 29 | 78.0% | 0 | 0 | 0 |
|  | `structural` | 37 | 30 | 81.0% | 0 | 0 | 0 |
|  | `isomorphism` | 37 | 31 | 84.0% | 0 | 0 | 0 |
| galaxy-data-mines | `always` | 19 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 19 | 11 | 58.0% | 0 | 0 | 0 |
|  | `structural` | 19 | 12 | 63.0% | 0 | 0 | 0 |
|  | `isomorphism` | 19 | 17 | 89.0% | 4 | 0 | 0 |
| gamespark | `always` | 13 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 13 | 11 | 85.0% | 0 | 0 | 0 |
|  | `structural` | 13 | 11 | 85.0% | 0 | 0 | 0 |
|  | `isomorphism` | 13 | 11 | 85.0% | 0 | 0 | 0 |
| gdxiris | `always` | 24 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 24 | 11 | 46.0% | 0 | 0 | 0 |
|  | `structural` | 24 | 13 | 54.0% | 0 | 0 | 0 |
|  | `isomorphism` | 24 | 15 | 62.0% | 0 | 0 | 0 |
| genetic-algorithm | `always` | 56 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 56 | 3 | 5.0% | 0 | 0 | 0 |
|  | `structural` | 56 | 13 | 23.0% | 0 | 0 | 0 |
|  | `isomorphism` | 56 | 24 | 43.0% | 4 | 0 | 0 |
| gestvae | `always` | 150 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 150 | 77 | 51.0% | 0 | 0 | 0 |
|  | `structural` | 150 | 89 | 59.0% | 0 | 0 | 0 |
|  | `isomorphism` | 150 | 96 | 64.0% | 10 | 0 | 0 |
| hotelaurademallorca | `always` | 150 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 150 | 61 | 41.0% | 0 | 0 | 0 |
|  | `structural` | 150 | 111 | 74.0% | 0 | 0 | 0 |
|  | `isomorphism` | 150 | 124 | 83.0% | 8 | 0 | 0 |
| hydgl | `always` | 72 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 72 | 46 | 64.0% | 0 | 0 | 0 |
|  | `structural` | 72 | 59 | 82.0% | 0 | 0 | 0 |
|  | `isomorphism` | 72 | 59 | 82.0% | 0 | 0 | 0 |
| ing-sw-2019-mauri-murriero-ostrovan | `always` | 114 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 114 | 54 | 47.0% | 0 | 0 | 0 |
|  | `structural` | 114 | 57 | 50.0% | 0 | 0 | 0 |
|  | `isomorphism` | 114 | 67 | 59.0% | 0 | 0 | 0 |
| is1-project-audio-streaming-system | `always` | 9 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 9 | 8 | 89.0% | 0 | 0 | 0 |
|  | `structural` | 9 | 8 | 89.0% | 0 | 0 | 0 |
|  | `isomorphism` | 9 | 8 | 89.0% | 0 | 0 | 0 |
| library-web-api | `always` | 22 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 22 | 19 | 86.0% | 0 | 0 | 0 |
|  | `structural` | 22 | 21 | 95.0% | 0 | 0 | 0 |
|  | `isomorphism` | 22 | 21 | 95.0% | 0 | 0 | 0 |
| meeting-room-display | `always` | 16 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 16 | 9 | 56.0% | 0 | 0 | 0 |
|  | `structural` | 16 | 12 | 75.0% | 0 | 0 | 0 |
|  | `isomorphism` | 16 | 13 | 81.0% | 0 | 0 | 0 |
| minesweeper | `always` | 98 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 98 | 32 | 33.0% | 0 | 0 | 0 |
|  | `structural` | 98 | 57 | 58.0% | 0 | 0 | 0 |
|  | `isomorphism` | 98 | 65 | 66.0% | 0 | 0 | 0 |
| model-wolf-sheep | `always` | 16 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 16 | 9 | 56.0% | 0 | 0 | 0 |
|  | `structural` | 16 | 13 | 81.0% | 0 | 0 | 0 |
|  | `isomorphism` | 16 | 13 | 81.0% | 0 | 0 | 0 |
| mschartextension | `always` | 30 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 30 | 10 | 33.0% | 0 | 0 | 0 |
|  | `structural` | 30 | 12 | 40.0% | 0 | 0 | 0 |
|  | `isomorphism` | 30 | 15 | 50.0% | 3 | 0 | 0 |
| open-market | `always` | 58 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 58 | 10 | 17.0% | 0 | 0 | 0 |
|  | `structural` | 58 | 11 | 19.0% | 0 | 0 | 0 |
|  | `isomorphism` | 58 | 11 | 19.0% | 0 | 0 | 0 |
| openpose-unity-plugin | `always` | 16 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 16 | 8 | 50.0% | 0 | 0 | 0 |
|  | `structural` | 16 | 11 | 69.0% | 0 | 0 | 0 |
|  | `isomorphism` | 16 | 12 | 75.0% | 0 | 0 | 0 |
| pbl03-dut-dk88 | `always` | 36 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 36 | 25 | 69.0% | 0 | 0 | 0 |
|  | `structural` | 36 | 25 | 69.0% | 0 | 0 | 0 |
|  | `isomorphism` | 36 | 25 | 69.0% | 0 | 0 | 0 |
| poker-bot-deep-rl | `always` | 81 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 81 | 27 | 33.0% | 0 | 0 | 0 |
|  | `structural` | 81 | 33 | 41.0% | 0 | 0 | 0 |
|  | `isomorphism` | 81 | 33 | 41.0% | 0 | 0 | 0 |
| preprocessinglayer-nordjyske | `always` | 60 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 60 | 42 | 70.0% | 0 | 0 | 0 |
|  | `structural` | 60 | 48 | 80.0% | 0 | 0 | 0 |
|  | `isomorphism` | 60 | 55 | 92.0% | 13 | 0 | 0 |
| prism-php | `always` | 67 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 67 | 22 | 33.0% | 0 | 0 | 0 |
|  | `structural` | 67 | 44 | 66.0% | 0 | 0 | 0 |
|  | `isomorphism` | 67 | 60 | 90.0% | 23 | 0 | 0 |
| projet-cy-books | `always` | 48 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 48 | 23 | 48.0% | 0 | 0 | 0 |
|  | `structural` | 48 | 30 | 62.0% | 0 | 0 | 0 |
|  | `isomorphism` | 48 | 30 | 62.0% | 0 | 0 | 0 |
| projet-hotel | `always` | 18 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 18 | 6 | 33.0% | 0 | 0 | 0 |
|  | `structural` | 18 | 7 | 39.0% | 0 | 0 | 0 |
|  | `isomorphism` | 18 | 10 | 56.0% | 3 | 0 | 0 |
| rdf4node | `always` | 150 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 150 | 14 | 9.0% | 0 | 0 | 0 |
|  | `structural` | 150 | 69 | 46.0% | 0 | 0 | 0 |
|  | `isomorphism` | 150 | 106 | 71.0% | 13 | 0 | 0 |
| scs-simulation-of-insulin-pump | `always` | 26 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 26 | 23 | 88.0% | 0 | 0 | 0 |
|  | `structural` | 26 | 24 | 92.0% | 0 | 0 | 0 |
|  | `isomorphism` | 26 | 24 | 92.0% | 0 | 0 | 0 |
| sistema-bancario | `always` | 25 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 25 | 16 | 64.0% | 0 | 0 | 0 |
|  | `structural` | 25 | 22 | 88.0% | 0 | 0 | 0 |
|  | `isomorphism` | 25 | 24 | 96.0% | 0 | 0 | 0 |
| soulland | `always` | 93 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 93 | 39 | 42.0% | 0 | 0 | 0 |
|  | `structural` | 93 | 52 | 56.0% | 0 | 0 | 0 |
|  | `isomorphism` | 93 | 54 | 58.0% | 1 | 0 | 0 |
| spring6plus | `always` | 38 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 38 | 28 | 74.0% | 0 | 0 | 0 |
|  | `structural` | 38 | 29 | 76.0% | 0 | 0 | 0 |
|  | `isomorphism` | 38 | 30 | 79.0% | 0 | 0 | 0 |
| tankman | `always` | 37 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 37 | 7 | 19.0% | 0 | 0 | 0 |
|  | `structural` | 37 | 20 | 54.0% | 0 | 0 | 0 |
|  | `isomorphism` | 37 | 26 | 70.0% | 9 | 0 | 0 |
| translator | `always` | 12 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 12 | 8 | 67.0% | 0 | 0 | 0 |
|  | `structural` | 12 | 8 | 67.0% | 0 | 0 | 0 |
|  | `isomorphism` | 12 | 10 | 83.0% | 6 | 0 | 0 |
| usms-web | `always` | 27 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 27 | 20 | 74.0% | 0 | 0 | 0 |
|  | `structural` | 27 | 22 | 81.0% | 0 | 0 | 0 |
|  | `isomorphism` | 27 | 22 | 81.0% | 0 | 0 | 0 |
| vars-annotation | `always` | 150 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 150 | 71 | 47.0% | 0 | 0 | 0 |
|  | `structural` | 150 | 78 | 52.0% | 0 | 0 | 0 |
|  | `isomorphism` | 150 | 78 | 52.0% | 0 | 0 | 0 |
| vectorx | `always` | 61 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 61 | 36 | 59.0% | 0 | 0 | 0 |
|  | `structural` | 61 | 37 | 61.0% | 0 | 0 | 0 |
|  | `isomorphism` | 61 | 38 | 62.0% | 0 | 0 | 0 |
| virtualq-final-version | `always` | 4 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 4 | 2 | 50.0% | 0 | 0 | 0 |
|  | `structural` | 4 | 2 | 50.0% | 0 | 0 | 0 |
|  | `isomorphism` | 4 | 2 | 50.0% | 0 | 0 | 0 |
| vscode-nativescript-extend | `always` | 126 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 126 | 98 | 78.0% | 0 | 0 | 0 |
|  | `structural` | 126 | 113 | 90.0% | 0 | 0 | 0 |
|  | `isomorphism` | 126 | 118 | 94.0% | 0 | 0 | 0 |
| xtask | `always` | 24 | 0 | 0.0% | 0 | 0 | — |
|  | `content` | 24 | 12 | 50.0% | 0 | 0 | 0 |
|  | `structural` | 24 | 14 | 58.0% | 0 | 0 | 0 |
|  | `isomorphism` | 24 | 14 | 58.0% | 0 | 0 | 0 |

## Table 4 — The controlled test

| Gate | Caught | Missed | False alarms | Correctly ignored | Precision | Recall |
|---|---:|---:|---:|---:|---:|---:|
| `always` | 10 | 0 | 6 | 0 | 0.62 | 1 |
| `content` | 10 | 0 | 6 | 0 | 0.62 | 1 |
| `structural` | 10 | 0 | 1 | 5 | 0.91 | 1 |
| `isomorphism` | 9 | 1 | 0 | 6 | 1 | 0.9 |

*Of 10 deliberate changes that break conformance, `always`, `content`, `structural` caught every one. `isomorphism` missed 1 — the known failure mode: a class renamed consistently everywhere leaves the code's shape unchanged, but still breaks a diagram that names that class. It is by design, and reporting it is stronger than hiding it.*

## Is the difference between the two gates real?

*On the 2606 commits both gates saw, they disagreed 177 times: `structural` re-analysed and `isomorphism` skipped on 177, the reverse on 0. That split is too lopsided to be chance (McNemar's exact test, p below 0.001), so the difference between these two gates is real rather than an accident of which commits happened to be in the corpus.*

## What the words mean

- **Skipped / skip rate** — The gate decided nothing important had changed, reused the previous result, and did not call the language model. This is the saving.
- **Missed / miss rate** — The gate skipped a commit where the findings actually did change — so it was wrong to skip. This is the cost of the saving. Never quote one without the other.
- **between X% and Y%** — A 95% interval. If the study were repeated, the true rate would very likely land in this range. A wide range means few runs, not a bad gate.
- **Tokens saved** — How many fewer tokens this gate spent than re-analysing every commit.
- **Divergence / absence** — Divergence: the code does something the diagram does not describe. Absence: the diagram describes something the code no longer does. Standard vocabulary in this field — use these words in the paper.
- **McNemar's test** — Asks whether two gates really behave differently, or whether the difference could be chance. It looks only at commits where the two disagreed, because the same commits go through both gates.

## Conformance drift

| Project | Provenance | Commits | Div. start→end | Abs. start→end | Drift/commit | Eroding | Repairing | Direction |
|---|---|---|---|---|---|---|---|---|
| androuter | found | 35 | 45→46 | 15→15 | 0.03 | 3 | 2 | divergence-led |
| angular-fullstack-pro-starter | found | 14 | 31→31 | 27→27 | 0 | 0 | 0 | stable |
| artvance | found | 25 | 25→33 | 70→75 | 0.54 | 4 | 0 | divergence-led |
| astrominer | found | 94 | 44→521 | 25→35 | 5.24 | 65 | 7 | divergence-led |
| bankthread | found | 7 | 29→38 | 10→10 | 1.5 | 2 | 2 | divergence-led |
| banquale | found | 34 | 51→58 | 18→18 | 0.21 | 4 | 2 | divergence-led |
| board-game | found | 11 | 53→52 | 36→36 | -0.1 | 0 | 1 | converging |
| codearteng-diagnostics | found | 12 | 84→95 | 18→18 | 1 | 4 | 0 | divergence-led |
| codingame-puzzles-stats-library | found | 150 | 17→80 | 12→15 | 0.44 | 23 | 3 | divergence-led |
| commandandcontrolsystem-lds | found | 13 | 146→146 | 16→16 | 0 | 0 | 0 | stable |
| cookpot | found | 57 | 9→36 | 25→39 | 0.73 | 15 | 2 | divergence-led |
| covid-vaccination-system | found | 12 | 67→67 | 56→56 | 0 | 0 | 0 | stable |
| discordbotrpg | found | 104 | 313→498 | 106→110 | 1.83 | 11 | 0 | divergence-led |
| django-business-logic | found | 27 | 137→138 | 55→55 | 0.04 | 1 | 0 | divergence-led |
| fire-app-builder | found | 18 | 610→751 | 175→208 | 10.24 | 3 | 1 | divergence-led |
| forma-tech | found | 10 | 124→148 | 57→67 | 3.78 | 5 | 0 | divergence-led |
| formula1-fisica | found | 37 | 6→9 | 21→21 | 0.08 | 3 | 0 | divergence-led |
| galaxy-data-mines | found | 19 | 16→18 | 25→26 | 0.17 | 2 | 0 | divergence-led |
| gamespark | found | 13 | 45→45 | 64→64 | 0 | 0 | 0 | stable |
| gdxiris | found | 24 | 3→14 | 8→7 | 0.43 | 3 | 0 | divergence-led |
| genetic-algorithm | found | 56 | 60→125 | 49→53 | 1.25 | 19 | 3 | divergence-led |
| gestvae | found | 150 | 26→144 | 32→49 | 0.91 | 45 | 4 | divergence-led |
| hotelaurademallorca | found | 150 | 66→75 | 10→15 | 0.09 | 7 | 0 | divergence-led |
| hydgl | found | 72 | 256→217 | 24→25 | -0.54 | 2 | 1 | absence-led |
| ing-sw-2019-mauri-murriero-ostrovan | found | 114 | 5→113 | 37→44 | 1.02 | 29 | 8 | divergence-led |
| is1-project-audio-streaming-system | found | 9 | 133→133 | 20→20 | 0 | 0 | 0 | stable |
| library-web-api | found | 22 | 17→17 | 30→30 | 0 | 0 | 0 | stable |
| meeting-room-display | found | 16 | 152→154 | 60→60 | 0.13 | 1 | 0 | divergence-led |
| minesweeper | found | 98 | 26→57 | 8→8 | 0.32 | 13 | 1 | divergence-led |
| model-wolf-sheep | found | 16 | 35→33 | 9→9 | -0.13 | 0 | 1 | converging |
| mschartextension | found | 30 | 118→189 | 22→22 | 2.45 | 9 | 1 | divergence-led |
| open-market | found | 58 | 62→98 | 10→10 | 0.63 | 12 | 2 | divergence-led |
| openpose-unity-plugin | found | 16 | 146→152 | 22→22 | 0.4 | 2 | 0 | divergence-led |
| pbl03-dut-dk88 | found | 36 | 33→58 | 44→60 | 1.17 | 5 | 2 | divergence-led |
| poker-bot-deep-rl | found | 81 | 51→99 | 55→55 | 0.6 | 9 | 3 | divergence-led |
| preprocessinglayer-nordjyske | found | 60 | 116→110 | 10→15 | -0.02 | 3 | 1 | absence-led |
| prism-php | found | 67 | 54→55 | 23→25 | 0.05 | 5 | 1 | absence-led |
| projet-cy-books | found | 48 | 220→236 | 71→71 | 0.34 | 4 | 2 | divergence-led |
| projet-hotel | found | 18 | 188→188 | 18→20 | 0.12 | 4 | 2 | absence-led |
| rdf4node | found | 150 | 84→116 | 39→37 | 0.2 | 13 | 4 | divergence-led |
| scs-simulation-of-insulin-pump | found | 26 | 292→292 | 44→44 | 0 | 0 | 0 | stable |
| sistema-bancario | found | 25 | 47→47 | 5→5 | 0 | 0 | 0 | stable |
| soulland | found | 93 | 9→71 | 5→5 | 0.67 | 22 | 8 | divergence-led |
| spring6plus | found | 38 | 81→118 | 10→10 | 1 | 3 | 0 | divergence-led |
| tankman | found | 37 | 125→98 | 56→60 | -0.64 | 6 | 1 | absence-led |
| translator | found | 12 | 29→36 | 10→10 | 0.64 | 1 | 0 | divergence-led |
| usms-web | found | 27 | 50→53 | 27→27 | 0.12 | 2 | 0 | divergence-led |
| vars-annotation | found | 150 | 430→466 | 19→17 | 0.23 | 26 | 3 | divergence-led |
| vectorx | found | 61 | 75→100 | 35→35 | 0.42 | 10 | 0 | divergence-led |
| virtualq-final-version | found | 4 | 72→74 | 137→137 | 0.67 | 1 | 0 | divergence-led |
| vscode-nativescript-extend | found | 126 | 30→37 | 14→14 | 0.06 | 4 | 1 | divergence-led |
| xtask | found | 24 | 270→331 | 1→2 | 2.7 | 7 | 0 | divergence-led |

- androuter: over 35 commits the code grew away from the design (divergence-led); divergences 45→46, absences 15→15, 3 eroding and 2 repairing commits.
- angular-fullstack-pro-starter: over 14 commits conformance did not move across the window; divergences 31→31, absences 27→27, 0 eroding and 0 repairing commits.
- artvance: over 25 commits the code grew away from the design (divergence-led); divergences 25→33, absences 70→75, 4 eroding and 0 repairing commits.
- astrominer: over 94 commits the code grew away from the design (divergence-led); divergences 44→521, absences 25→35, 65 eroding and 7 repairing commits.
- bankthread: over 7 commits the code grew away from the design (divergence-led); divergences 29→38, absences 10→10, 2 eroding and 2 repairing commits.
- banquale: over 34 commits the code grew away from the design (divergence-led); divergences 51→58, absences 18→18, 4 eroding and 2 repairing commits.
- board-game: over 11 commits the code moved back towards the design; divergences 53→52, absences 36→36, 0 eroding and 1 repairing commits.
- codearteng-diagnostics: over 12 commits the code grew away from the design (divergence-led); divergences 84→95, absences 18→18, 4 eroding and 0 repairing commits.
- codingame-puzzles-stats-library: over 150 commits the code grew away from the design (divergence-led); divergences 17→80, absences 12→15, 23 eroding and 3 repairing commits.
- commandandcontrolsystem-lds: over 13 commits conformance did not move across the window; divergences 146→146, absences 16→16, 0 eroding and 0 repairing commits.
- cookpot: over 57 commits the code grew away from the design (divergence-led); divergences 9→36, absences 25→39, 15 eroding and 2 repairing commits.
- covid-vaccination-system: over 12 commits conformance did not move across the window; divergences 67→67, absences 56→56, 0 eroding and 0 repairing commits.
- discordbotrpg: over 104 commits the code grew away from the design (divergence-led); divergences 313→498, absences 106→110, 11 eroding and 0 repairing commits.
- django-business-logic: over 27 commits the code grew away from the design (divergence-led); divergences 137→138, absences 55→55, 1 eroding and 0 repairing commits.
- fire-app-builder: over 18 commits the code grew away from the design (divergence-led); divergences 610→751, absences 175→208, 3 eroding and 1 repairing commits.
- forma-tech: over 10 commits the code grew away from the design (divergence-led); divergences 124→148, absences 57→67, 5 eroding and 0 repairing commits.
- formula1-fisica: over 37 commits the code grew away from the design (divergence-led); divergences 6→9, absences 21→21, 3 eroding and 0 repairing commits.
- galaxy-data-mines: over 19 commits the code grew away from the design (divergence-led); divergences 16→18, absences 25→26, 2 eroding and 0 repairing commits.
- gamespark: over 13 commits conformance did not move across the window; divergences 45→45, absences 64→64, 0 eroding and 0 repairing commits.
- gdxiris: over 24 commits the code grew away from the design (divergence-led); divergences 3→14, absences 8→7, 3 eroding and 0 repairing commits.
- genetic-algorithm: over 56 commits the code grew away from the design (divergence-led); divergences 60→125, absences 49→53, 19 eroding and 3 repairing commits.
- gestvae: over 150 commits the code grew away from the design (divergence-led); divergences 26→144, absences 32→49, 45 eroding and 4 repairing commits.
- hotelaurademallorca: over 150 commits the code grew away from the design (divergence-led); divergences 66→75, absences 10→15, 7 eroding and 0 repairing commits.
- hydgl: over 72 commits the design went stale as designed elements disappeared (absence-led); divergences 256→217, absences 24→25, 2 eroding and 1 repairing commits.
- ing-sw-2019-mauri-murriero-ostrovan: over 114 commits the code grew away from the design (divergence-led); divergences 5→113, absences 37→44, 29 eroding and 8 repairing commits.
- is1-project-audio-streaming-system: over 9 commits conformance did not move across the window; divergences 133→133, absences 20→20, 0 eroding and 0 repairing commits.
- library-web-api: over 22 commits conformance did not move across the window; divergences 17→17, absences 30→30, 0 eroding and 0 repairing commits.
- meeting-room-display: over 16 commits the code grew away from the design (divergence-led); divergences 152→154, absences 60→60, 1 eroding and 0 repairing commits.
- minesweeper: over 98 commits the code grew away from the design (divergence-led); divergences 26→57, absences 8→8, 13 eroding and 1 repairing commits.
- model-wolf-sheep: over 16 commits the code moved back towards the design; divergences 35→33, absences 9→9, 0 eroding and 1 repairing commits.
- mschartextension: over 30 commits the code grew away from the design (divergence-led); divergences 118→189, absences 22→22, 9 eroding and 1 repairing commits.
- open-market: over 58 commits the code grew away from the design (divergence-led); divergences 62→98, absences 10→10, 12 eroding and 2 repairing commits.
- openpose-unity-plugin: over 16 commits the code grew away from the design (divergence-led); divergences 146→152, absences 22→22, 2 eroding and 0 repairing commits.
- pbl03-dut-dk88: over 36 commits the code grew away from the design (divergence-led); divergences 33→58, absences 44→60, 5 eroding and 2 repairing commits.
- poker-bot-deep-rl: over 81 commits the code grew away from the design (divergence-led); divergences 51→99, absences 55→55, 9 eroding and 3 repairing commits.
- preprocessinglayer-nordjyske: over 60 commits the design went stale as designed elements disappeared (absence-led); divergences 116→110, absences 10→15, 3 eroding and 1 repairing commits.
- prism-php: over 67 commits the design went stale as designed elements disappeared (absence-led); divergences 54→55, absences 23→25, 5 eroding and 1 repairing commits.
- projet-cy-books: over 48 commits the code grew away from the design (divergence-led); divergences 220→236, absences 71→71, 4 eroding and 2 repairing commits.
- projet-hotel: over 18 commits the design went stale as designed elements disappeared (absence-led); divergences 188→188, absences 18→20, 4 eroding and 2 repairing commits.
- rdf4node: over 150 commits the code grew away from the design (divergence-led); divergences 84→116, absences 39→37, 13 eroding and 4 repairing commits.
- scs-simulation-of-insulin-pump: over 26 commits conformance did not move across the window; divergences 292→292, absences 44→44, 0 eroding and 0 repairing commits.
- sistema-bancario: over 25 commits conformance did not move across the window; divergences 47→47, absences 5→5, 0 eroding and 0 repairing commits.
- soulland: over 93 commits the code grew away from the design (divergence-led); divergences 9→71, absences 5→5, 22 eroding and 8 repairing commits.
- spring6plus: over 38 commits the code grew away from the design (divergence-led); divergences 81→118, absences 10→10, 3 eroding and 0 repairing commits.
- tankman: over 37 commits the design went stale as designed elements disappeared (absence-led); divergences 125→98, absences 56→60, 6 eroding and 1 repairing commits.
- translator: over 12 commits the code grew away from the design (divergence-led); divergences 29→36, absences 10→10, 1 eroding and 0 repairing commits.
- usms-web: over 27 commits the code grew away from the design (divergence-led); divergences 50→53, absences 27→27, 2 eroding and 0 repairing commits.
- vars-annotation: over 150 commits the code grew away from the design (divergence-led); divergences 430→466, absences 19→17, 26 eroding and 3 repairing commits.
- vectorx: over 61 commits the code grew away from the design (divergence-led); divergences 75→100, absences 35→35, 10 eroding and 0 repairing commits.
- virtualq-final-version: over 4 commits the code grew away from the design (divergence-led); divergences 72→74, absences 137→137, 1 eroding and 0 repairing commits.
- vscode-nativescript-extend: over 126 commits the code grew away from the design (divergence-led); divergences 30→37, absences 14→14, 4 eroding and 1 repairing commits.
- xtask: over 24 commits the code grew away from the design (divergence-led); divergences 270→331, absences 1→2, 7 eroding and 0 repairing commits.

### Element survival (time to first deviation)

| Project | Designed | Conforming at freeze | Deviated in window | Survival at end | Half-life (commits) |
|---|---|---|---|---|---|
| androuter | 8 | 0 | 0 | None | > 34 (not reached) |
| angular-fullstack-pro-starter | 8 | 0 | 0 | None | > 13 (not reached) |
| artvance | 15 | 0 | 0 | None | > 24 (not reached) |
| astrominer | 15 | 0 | 0 | None | > 93 (not reached) |
| bankthread | 5 | 0 | 0 | None | > 6 (not reached) |
| banquale | 16 | 5 | 1 | 0.8 | > 33 (not reached) |
| board-game | 23 | 3 | 0 | 1 | > 10 (not reached) |
| codearteng-diagnostics | 11 | 1 | 0 | 1 | > 11 (not reached) |
| codingame-puzzles-stats-library | 10 | 0 | 0 | None | > 149 (not reached) |
| commandandcontrolsystem-lds | 7 | 0 | 0 | None | > 12 (not reached) |
| cookpot | 20 | 6 | 4 | 0.33 | 50 |
| covid-vaccination-system | 19 | 0 | 0 | None | > 11 (not reached) |
| discordbotrpg | 22 | 0 | 0 | None | > 103 (not reached) |
| django-business-logic | 18 | 0 | 0 | None | > 26 (not reached) |
| fire-app-builder | 114 | 3 | 1 | 0.67 | > 17 (not reached) |
| forma-tech | 9 | 0 | 0 | None | > 9 (not reached) |
| formula1-fisica | 9 | 2 | 0 | 1 | > 36 (not reached) |
| galaxy-data-mines | 6 | 0 | 0 | None | > 18 (not reached) |
| gamespark | 53 | 32 | 0 | 1 | > 12 (not reached) |
| gdxiris | 6 | 1 | 1 | 0 | 1 |
| genetic-algorithm | 19 | 4 | 4 | 0 | 2 |
| gestvae | 12 | 0 | 0 | None | > 149 (not reached) |
| hotelaurademallorca | 13 | 0 | 0 | None | > 149 (not reached) |
| hydgl | 24 | 11 | 0 | 1 | > 71 (not reached) |
| ing-sw-2019-mauri-murriero-ostrovan | 16 | 11 | 11 | 0 | 13 |
| is1-project-audio-streaming-system | 10 | 0 | 0 | None | > 8 (not reached) |
| library-web-api | 12 | 0 | 0 | None | > 21 (not reached) |
| meeting-room-display | 25 | 1 | 0 | 1 | > 15 (not reached) |
| minesweeper | 6 | 1 | 0 | 1 | > 97 (not reached) |
| model-wolf-sheep | 8 | 0 | 0 | None | > 15 (not reached) |
| mschartextension | 18 | 0 | 0 | None | > 29 (not reached) |
| open-market | 12 | 2 | 0 | 1 | > 57 (not reached) |
| openpose-unity-plugin | 10 | 0 | 0 | None | > 15 (not reached) |
| pbl03-dut-dk88 | 9 | 0 | 0 | None | > 35 (not reached) |
| poker-bot-deep-rl | 12 | 0 | 0 | None | > 80 (not reached) |
| preprocessinglayer-nordjyske | 21 | 3 | 0 | 1 | > 59 (not reached) |
| prism-php | 12 | 1 | 0 | 1 | > 66 (not reached) |
| projet-cy-books | 23 | 0 | 0 | None | > 47 (not reached) |
| projet-hotel | 14 | 0 | 0 | None | > 17 (not reached) |
| rdf4node | 20 | 2 | 0 | 1 | > 149 (not reached) |
| scs-simulation-of-insulin-pump | 7 | 0 | 0 | None | > 25 (not reached) |
| sistema-bancario | 8 | 1 | 0 | 1 | > 24 (not reached) |
| soulland | 5 | 3 | 3 | 0 | 7 |
| spring6plus | 24 | 8 | 0 | 1 | > 37 (not reached) |
| tankman | 22 | 0 | 0 | None | > 36 (not reached) |
| translator | 12 | 2 | 1 | 0.5 | 3 |
| usms-web | 7 | 0 | 0 | None | > 26 (not reached) |
| vars-annotation | 16 | 3 | 0 | 1 | > 149 (not reached) |
| vectorx | 10 | 6 | 0 | 1 | > 60 (not reached) |
| virtualq-final-version | 13 | 0 | 0 | None | > 3 (not reached) |
| vscode-nativescript-extend | 16 | 6 | 0 | 1 | > 125 (not reached) |
| xtask | 24 | 1 | 0 | 1 | > 23 (not reached) |

Pooled over 52 project(s): 26 of 119 initially conforming elements deviated inside the window; fewer than half deviated, so the half-life is not reached.
