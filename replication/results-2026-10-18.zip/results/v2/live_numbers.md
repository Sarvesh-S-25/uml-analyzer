﻿## Seeded deviations, live model
| Gate | Real calls | Prompt tokens (Ollama) | Completion tokens | Model time, s | Changed-element coverage (10 changing) | Fully named | Ungrounded mentions |
|---|---|---|---|---|---|---|---|
| always | 16 | 63,109 | 7,416 | 772 | 0.65 (n=10) | 5/10 | 0 |
| content | 16 | 40,584 (−36%) | 6,992 | 645 | 0.56 (n=10) | 3/10 | 0 |
| structural | 11 | 22,353 (−65%) | 4,974 | 448 | 0.56 (n=10) | 3/10 | 0 |
| isomorphism | 9 | 17,758 (−72%) | 3,660 | 334 | 0.48 (n=10) | 3/10 | 0 |

Per mutation (coverage of the changed elements by the served explanation):
| Mutation | Changes findings | always | content | structural | isomorphism |
|---|---|---|---|---|---|
| delete-designed-method | True | 1.00 | 1.00 | 1.00 | 1.00 |
| add-undocumented-class | True | 0.00 | 1.00 | 1.00 | 1.00 |
| remove-realization | True | 0.50 | 0.50 | 0.50 | 0.50 |
| break-association | True | 1.00 | 0.33 | 0.33 | 0.33 |
| controller-bypasses-service | True | 0.00 | 0.00 | 0.00 | 0.00 |
| invert-dependency | True | 0.50 | 0.50 | 0.50 | 0.50 |
| rename-class-partially | True | 1.00 | 1.00 | 1.00 | 1.00 |
| rename-class-consistently | True | 1.00 | 0.75 | 0.75 | 0.00 (reused) |
| delete-designed-class | True | 0.50 | 0.50 | 0.50 | 0.50 |
| add-private-helper | True | 1.00 | 0.00 | 0.00 | 0.00 |
| change-parameter-count | False | — | — | — | — (reused) |
| comment-only | False | — | — | — (reused) | — (reused) |
| reformat-whitespace | False | — | — | — (reused) | — (reused) |
| rename-local-variable | False | — | — | — (reused) | — (reused) |
| reorder-methods | False | — | — | — (reused) | — (reused) |
| add-docstring | False | — | — | — (reused) | — (reused) |
- full-project (always): prompt tokens 3,920 [3,910–3,966]; model time 46.7 s [40.2–54.0]; prompt eval 10.7 s [9.4–10.9]; generation 39.4 s [26.4–42.1]
- scoped (structural): prompt tokens 1,964 [1,855–2,112]; model time 39.0 s [31.4–44.2]; prompt eval 4.0 s [3.8–4.5]; generation 32.0 s [24.0–37.4]

## Repeatability (same prompt sent twice, cache bypassed)
- pairs: 13; byte-identical answers: 11; identical gap lists: 12
- second-call time / first-call time: median 0.80 (range 0.71–0.90)
- scored rows with identical coverage and ungrounded counts: 12/12

## Counterfactual estimate vs measured prompt tokens
- calls: 59; Ollama tokens / cl100k estimate: median 1.051 (IQR 1.039–1.061; range 1.021–1.092)
- truncated by Ollama: 0; bad JSON answers: see runs
- throughput: prompt 365 tok/s, generation 12.9 tok/s (medians)

## Live corpus replay
| Project | Gate | Runs | Gate fired | Sent | Fits? no_fit | Not sampled | Bad JSON | Prompt tokens (Ollama) | Model time, s | Counterfactual tokens |
|---|---|---|---|---|---|---|---|---|---|---|
| bankthread | always | 7 | 7 | 5 | 0 | 2 | 1 | 30,428 | 691 | 0 |
| bankthread | content | 7 | 6 | 6 | 0 | 0 | 1 | 27,009 | 666 | 0 |
| bankthread | structural | 7 | 5 | 5 | 0 | 0 | 1 | 21,236 | 563 | 0 |
| bankthread | isomorphism | 7 | 5 | 5 | 0 | 0 | 1 | 21,236 | 563 | 0 |
| banquale | always | 34 | 34 | 6 | 4 | 24 | 4 | 162,738 | 3,607 | 0 |
| banquale | content | 34 | 12 | 12 | 0 | 0 | 5 | 197,477 | 4,590 | 0 |
| banquale | structural | 34 | 9 | 9 | 0 | 0 | 4 | 114,868 | 2,875 | 0 |
| banquale | isomorphism | 34 | 8 | 8 | 0 | 0 | 3 | 107,668 | 2,665 | 0 |
| **all** | always | 41 | 41 | 11 | 4 | 26 | 5 | 193,166 | 4,298 | 0 |
| **all** | content | 41 | 18 | 18 | 0 | 0 | 6 | 224,486 | 5,256 | 0 |
| **all** | structural | 41 | 14 | 14 | 0 | 0 | 5 | 136,104 | 3,438 | 0 |
| **all** | isomorphism | 41 | 13 | 13 | 0 | 0 | 4 | 128,904 | 3,228 | 0 |
- always: 11/15 fired prompts fit the window (73%, CI 48–89%)
- content: 18/18 fired prompts fit the window (100%, CI 82–100%)
- structural: 14/14 fired prompts fit the window (100%, CI 78–100%)
- isomorphism: 13/13 fired prompts fit the window (100%, CI 77–100%)

Served-explanation coverage at commits where the deterministic findings changed:
- always: n=6; mean 0.50
- content: n=6; mean 0.34
- structural: n=6; mean 0.34
- isomorphism: n=6; mean 0.34
- always: ungrounded mentions per sent call: 0.00 (n=6)
- content: ungrounded mentions per sent call: 0.00 (n=12)
- structural: ungrounded mentions per sent call: 0.00 (n=9)
- isomorphism: ungrounded mentions per sent call: 0.00 (n=9)
