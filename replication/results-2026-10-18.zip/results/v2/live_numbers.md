## Seeded deviations, live model
| Gate | Real calls | Prompt tokens (Ollama) | Completion tokens | Model time, s | Changed-element coverage (10 changing) | Fully named | Ungrounded mentions |
|---|---|---|---|---|---|---|---|
| always | 16 | 63,109 | 7,416 | 772 | 0.65 (n=10) | 5/10 | 0 |
| content | 16 | 40,584 (−36%) | 6,992 | 645 | 0.56 (n=10) | 3/10 | 0 |
| structural | 11 | 22,353 (−65%) | 4,974 | 448 | 0.56 (n=10) | 3/10 | 0 |
| isomorphism | 9 | 17,758 (−72%) | 3,660 | 334 | 0.48 (n=10) | 3/10 | 0 |

Per mutation (coverage of the changed elements by the served explanation):
| Mutation | Changes findings | always | content | structural | isomorphism |
|---|---|---|---|---|---|
| delete-designed-method | True | 1.00 | 1.00 | 1.00 | 1.00 |
| add-undocumented-class | True | 0.00 | 1.00 | 1.00 | 1.00 |
| remove-realization | True | 0.50 | 0.50 | 0.50 | 0.50 |
| break-association | True | 1.00 | 0.33 | 0.33 | 0.33 |
| controller-bypasses-service | True | 0.00 | 0.00 | 0.00 | 0.00 |
| invert-dependency | True | 0.50 | 0.50 | 0.50 | 0.50 |
| rename-class-partially | True | 1.00 | 1.00 | 1.00 | 1.00 |
| rename-class-consistently | True | 1.00 | 0.75 | 0.75 | 0.00 (reused) |
| delete-designed-class | True | 0.50 | 0.50 | 0.50 | 0.50 |
| add-private-helper | True | 1.00 | 0.00 | 0.00 | 0.00 |
| change-parameter-count | False | — | — | — | — (reused) |
| comment-only | False | — | — | — (reused) | — (reused) |
| reformat-whitespace | False | — | — | — (reused) | — (reused) |
| rename-local-variable | False | — | — | — (reused) | — (reused) |
| reorder-methods | False | — | — | — (reused) | — (reused) |
| add-docstring | False | — | — | — (reused) | — (reused) |
- full-project (always): prompt tokens 3,920 [3,910–3,966]; model time 46.7 s [40.2–54.0]; prompt eval 10.7 s [9.4–10.9]; generation 39.4 s [26.4–42.1]
- scoped (structural): prompt tokens 1,964 [1,855–2,112]; model time 39.0 s [31.4–44.2]; prompt eval 4.0 s [3.8–4.5]; generation 32.0 s [24.0–37.4]

## Repeatability (same prompt sent twice, cache bypassed)
- pairs: 13; byte-identical answers: 11; identical gap lists: 12
- second-call time / first-call time: median 0.80 (range 0.71–0.90)
- scored rows with identical coverage and ungrounded counts: 12/12

## Counterfactual estimate vs measured prompt tokens
- calls: 45; Ollama tokens / cl100k estimate: median 1.051 (IQR 1.042–1.068; range 1.029–1.092)
- truncated by Ollama: 0; bad JSON answers: see runs
- throughput: prompt 376 tok/s, generation 12.9 tok/s (medians)
