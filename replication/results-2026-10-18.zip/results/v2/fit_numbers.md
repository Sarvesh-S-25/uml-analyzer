## Fit to a 32,768-token window (send threshold 27,853 model tokens, ratio 1.051)
| Gate | Fired prompts | Fit | Share [95% CI] | Median size (model tokens) | 90th percentile |
|---|---|---|---|---|---|
| always | 2443 | 991 | 41% [39–43] | 39,665 | 151,624 |
| content | 1318 | 999 | 76% [73–78] | 12,903 | 60,489 |
| structural | 975 | 870 | 89% [87–91] | 8,779 | 29,704 |
| isomorphism | 798 | 697 | 87% [85–89] | 9,858 | 33,455 |

- projects: 50
- projects whose full-project prompt never fits: 19
- projects whose full-project prompt always fits: 21
- projects where every structural re-analysis fits: 28
